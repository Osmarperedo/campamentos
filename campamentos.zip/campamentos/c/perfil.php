<?php
require_once '../m/db_functions.php';

/*$id='';
$nombre='';
$estado='';*/
if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['id'])){
		$id = $_POST['id'];
	}
	if(isset($_POST['nombre'])){
		$nombre = $_POST['nombre'];

	}
}
// Instance of a User class
$userObject = new DB_Functions();
	// registrar
	if(empty($id) && !empty($nombre)){
		$json_registration = $userObject->createPerfil($nombre);
		//echo $json_registration;
		}elseif(!empty($id) && !empty($nombre) ){
			$json_registration = $userObject->updatePerfil($id,$nombre);
			//echo $json_registration;	
			//} //elseif(!empty($id) && empty($nombre) ){
//				$json_registration = $userObject-> delAlgoritmo($id);
				//	echo "\n nine".$id."-".$nombre."-".$estado;	
	}else{
		echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert"> <img src="../../gcm_chat/loader.gif"> Error de conexion al servidor</div></div>';
	} 
?>