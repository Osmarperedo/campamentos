<?php

//include ("../modelo/smsencrip.php");
require_once '../m/db_functions.php';
//require_once __DIR__ . '../modelo/smsencrip.php';
$user = $_POST['username'];
$pass = $_POST['password'];  

$passw=md5($pass);
//$user='abner';
//$pass=md5('abner');

$wish = new DB_Functions();
$wish->login($user,$passw); 

?>