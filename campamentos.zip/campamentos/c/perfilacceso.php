<?php
require_once '../m/db_functions.php';

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['perfil'])){
		$idp = $_POST['perfil'];
	}
	
    if (isset($_POST['check_list']))  {
     	$idr = $_POST['check_list'];
     	$recid = substr($idr, 0, -1);
    }

    
}
//echo $id."---".$colors;
// Instance of a User class
$userObject = new DB_Functions();
	// registrar
	if(!empty($idp) && !empty($recid)){
		$json_registration = $userObject->createperfilacceso($recid,$idp);
		//echo $json_registration;
		}elseif(empty($id) && !empty($colors) ){
			$json_registration = $userObject->updatePerfil($id,$nombre);
			//echo $json_registration;	
			//} //elseif(!empty($id) && empty($nombre) ){
//				$json_registration = $userObject-> delAlgoritmo($id);
				//	echo "\n nine".$id."-".$nombre."-".$estado;	
	}else{
		echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert"> <img src="../../gcm_chat/loader.gif"> Error de conexion al servidor</div></div>';
	} 


/*if(!empty($_POST['check_list'])){
     foreach($_POST['check_list'] as $report_id){
        echo "$report_id was checked! ";
     }
   }
   $flavours = implode(',', $flavours);
*/

?>