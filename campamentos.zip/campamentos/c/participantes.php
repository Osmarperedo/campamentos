<?php
require_once '../m/db_functions.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['id'])){
		$id = $_POST['id'];
	}
	if(isset($_POST['nombre'])){
		$nombre = $_POST['nombre'];
	}
	if(isset($_POST['apellido'])){
	    $apellido = $_POST['apellido'];
	    //echo $password;
	}
	if(isset($_POST['telefono'])){
		$telefono = $_POST['telefono'];
	}
	if(isset($_POST['celular'])){
		$celular = $_POST['celular'];
	}
	if(isset($_POST['email'])){
		$email = $_POST['email'];
	}
	if(isset($_POST['direccion'])){
		$direccion = $_POST['direccion'];
	}
	if(isset($_POST['ci'])){
		$ci = $_POST['ci'];
	}
	if(isset($_POST['iglesia'])){
		$iglesia = $_POST['iglesia'];
	}
	if(isset($_POST['usuario'])){
		$usu = $_POST['usuario'];
	}
	if(isset($_POST['password'])){
		$pass = $_POST['password'];
	}

}
// Instance of a User class
$userObject = new DB_Functions();

//----------------- REGISTRAR
if(empty($id) && !empty($nombre) && !empty($apellido) && !empty($telefono) && !empty($celular) && !empty($email) && !empty($direccion) && !empty($ci) && !empty($iglesia) && !empty($usu) && !empty($pass)){
		$hashed_password = md5($pass);
		$json_registration = $userObject->createParticipante($nombre,$apellido,$telefono,$celular,$email,$direccion,$ci,$iglesia,$usu,$hashed_password);
		echo $json_registration;
		//---------------- MOODIFICAR
	}elseif (!empty($id) && !empty($nombre) && !empty($apellido)&& !empty($telefono) && !empty($celular)&& !empty($email)&& !empty($direccion)&& !empty($ci) && !empty($iglesia)&& !empty($usu) && empty($pass)) {
		$hashed_password = md5($pass);
			$json_registration = $userObject-> updateParticipante($id,$nombre ,$apellido,$celular ,$email,$direccion,$ci,$estado,$hashed_password);
			echo "modificar";
		//	echo $json_registration;	
		// ---------- ELIMINAR
		}elseif (!empty($id) && empty($nombre) && empty($apellido) && empty($celular)&& empty($email) && empty($direccion)&& empty($ci) && empty($usu) && empty($pass)) {
				$json_registration = $userObject-> deleteUsuario($id);
		//		echo $json_registration;
		//------ resetear contraseña		
		}elseif (!empty($id) && empty($nombre) && empty($apellido) && empty($celular)&& empty($email) && empty($direccion)&& empty($ci) && !empty($usu) && empty($pass)) {
				$passw = md5($usu);
				$json_registration = $userObject-> resetUsuario($usu,$passw);
				echo "eliminar";
		//		echo $json_registration;	
}
else{
	echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert"> <img src="../../gcm_chat/loader.gif"> Error de conexion al servidor</div></div>';
}



?>