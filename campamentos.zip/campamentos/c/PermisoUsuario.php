<?php
require_once '../m/db_functions.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['id'])){
		$id = $_POST['id'];
	}
	if(isset($_POST['perm'])){
		$permiso = $_POST['perm'];

	}
	if(isset($_POST['env'])){
		$reg = $_POST['env'];

	}
}
// Instance of a User class
$userObject = new DB_Functions();
	// registrar
	if(!empty($id) && !empty($permiso)&& !empty($reg)){
		$json_registration = $userObject->createpermisousuario($id,$permiso);
		}elseif(empty($id) && empty($permiso) ){
			$json_registration = $userObject->updatePerfil($id,$permiso);
			
	}else{
		echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert"> <img src="../../gcm_chat/loader.gif"> Error de conexion al servidor</div></div>';
	} 
?>