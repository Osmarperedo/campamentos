<?php
require_once '../m/db_functions.php';

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['idp'])){
		$idp= $_POST['idp'];
	}	
	if(isset($_POST['monto'])){
		$monto = $_POST['monto'];
	}
	if(isset($_POST['imagen'])){
		$imagen = $_POST['imagen'];
	}	
}
// Instance of a User class
$userObject = new DB_Functions();

//----------------- REGISTRAR
if(!empty($idp) && !empty($monto) && !empty($imagen) ){
	
		$json_registration = $userObject->pagorealizado($idp ,$monto,$imagen);
		echo $json_registration;
		//---------------- MOODIFICAR
	}
else{
	echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert"> <img src="../../gcm_chat/loader.gif"> Error de conexion al servidor</div></div>';
}



?>