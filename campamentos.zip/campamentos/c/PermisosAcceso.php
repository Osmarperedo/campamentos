<?php
require_once '../m/db_functions.php';

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['id'])){
		$idp = $_POST['id'];
	}

    if (isset($_POST['prec']))  {
     
     	$idr = explode(',',substr($_POST['prec'], 0, -1));
    }
    if (isset($_POST['c']))  {
     	$c =  explode(',',substr($_POST['c'], 0, -1));
    }
    if (isset($_POST['r']))  {
     	$r =  explode(',',substr($_POST['r'], 0, -1));
    }
    if (isset($_POST['u']))  {
     	$u = explode(',', substr($_POST['u'], 0, -1));
    }   
    if (isset($_POST['d']))  {
     	$d = explode(',',substr($_POST['d'], 0, -1));
    }   
    if (isset($_POST['pu']))  {
        $pu = explode(',',substr($_POST['pu'], 0, -1));
    } 
    if (isset($_POST['cn']))  {
        $cn = explode(',',substr($_POST['cn'], 0, -1));
    } 
    if (isset($_POST['a']))  {
        $a =  explode(',',substr($_POST['a'], 0, -1));
    }
    if (isset($_POST['pr']))  {
        $pr =  explode(',',substr($_POST['pr'], 0, -1));
    }
    echo $idp; print_r($idr); print_r($c); print_r($r); print_r($u); print_r($d); print_r($pu); print_r($cn); print_r($a); print_r($pr);
}

$userObject = new DB_Functions();
	// registrar
	if(!empty($idp) && !empty($idr) && !empty($c) && !empty($r) && !empty($u) && !empty($d)&& !empty($pu)&& !empty($cn)&& !empty($a)&& !empty($pr)){
        $json_registration = $userObject->updatepermisoacceso($idp,$idr,$c,$r,$u,$d,$pu,$cn,$a,$pr);
		//echo $json_registration;
	}else{
		echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert"> <img src="../../gcm_chat/loader.gif"> Error de conexion al servidor</div></div>';
	} 
?>

