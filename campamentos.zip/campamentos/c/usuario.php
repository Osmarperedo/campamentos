<?php
require_once '../m/db_functions.php';

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['id'])){
		$id = $_POST['id'];
	}

	if(isset($_POST['nombrep'])){
		$nombre = $_POST['nombrep'];
	}
	if(isset($_POST['apellidop'])){
	    $apellido = $_POST['apellidop'];
	    //echo $password;
	}
	if(isset($_POST['celular'])){
		$celular = $_POST['celular'];
	}
	if(isset($_POST['email'])){
		$email = $_POST['email'];
	}
	if(isset($_POST['direccion'])){
		$direccion = $_POST['direccion'];
	}
	if(isset($_POST['ci'])){
		$ci = $_POST['ci'];
	}
	if(isset($_POST['usuario'])){
		$usu = $_POST['usuario'];
	}
	if(isset($_POST['password'])){
		$pass = $_POST['password'];
	}
	if(isset($_POST['estado'])){
		$estado = $_POST['estado'];
	}
}
// Instance of a User class
$userObject = new DB_Functions();

//----------------- REGISTRAR
if(empty($id) && !empty($nombre) && !empty($apellido) && !empty($celular)&& !empty($email) && !empty($direccion)&& !empty($ci) && !empty($usu) && !empty($pass) && empty($estado)){
		$hashed_password = md5($pass);
		$json_registration = $userObject->createUsuario($nombre ,$apellido,$celular ,$email,$direccion,$ci,$estado,$usu,$hashed_password);
		echo $json_registration;
		//---------------- MOODIFICAR
	}elseif (!empty($id) && !empty($nombre) && !empty($apellido) && !empty($celular)&& !empty($direccion)&& !empty($ci) && !empty($usu) && empty($pass)) {
			$json_registration = $userObject-> updateUsuario($id,$nombre ,$apellido,$celular ,$email,$direccion,$ci,$estado);
		//	echo $json_registration;	
		// ---------- ELIMINAR
		}elseif (!empty($id) && empty($nombre) && empty($apellido) && empty($celular)&& empty($email) && empty($direccion)&& empty($ci) && empty($usu) && empty($pass)) {
				$json_registration = $userObject-> deleteUsuario($id);
		//		echo $json_registration;
		//------ resetear contraseña		
		}elseif (!empty($id) && empty($nombre) && empty($apellido) && empty($celular)&& empty($email) && empty($direccion)&& empty($ci) && !empty($usu) && empty($pass)) {
				$passw = md5($usu);
				$json_registration = $userObject-> resetUsuario($usu,$passw);
		//		echo $json_registration;	
}
else{
	echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert"> <img src="../../gcm_chat/loader.gif"> Error de conexion al servidor</div></div>';
}



?>