<?php
require_once '../m/db_functions.php';

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['idp'])){
		$idp = $_POST['idp'];
	}

	if(isset($_POST['idc'])){
		$idc = $_POST['idc'];
	}
	if(isset($_POST['fi'])){
	    $fi = $_POST['fi'];
	    //echo $password;
	}
	if(isset($_POST['fp'])){
		$fp = $_POST['fp'];
	}
	if(isset($_POST['monto'])){
		$monto = $_POST['monto'];
	}
	echo $idp;
	echo $idc;
	echo $fi;
	echo $fp;
	echo $monto;
}
// Instance of a User class
$userObject = new DB_Functions();

//----------------- REGISTRAR
if(!empty($idp) && !empty($idc) && !empty($fi) && !empty($fp) && !empty($monto)){
		$json_registration = $userObject->createregistropago($idp,$idc,$fi,$fp,$monto);
		echo $json_registration;
		//---------------- MOODIFICAR
	}elseif(empty($idp) && !empty($idc) && !empty($fi) && !empty($fp)) {
			$json_registration = $userObject-> updateUsuario($idp ,$idc,$fi ,$fp);	
}
else{
	echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert"> <img src="../../gcm_chat/loader.gif"> Error de conexion al servidor</div></div>';
}



?>