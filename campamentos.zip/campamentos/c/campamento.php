<?php
require_once '../m/db_functions.php';



if($_SERVER['REQUEST_METHOD']=='POST'){
	
	if(isset($_POST['id'])){
		$id = $_POST['id'];
	}
	if(isset($_POST['costoid'])){
		$costoid = $_POST['costoid'];
	}
	if(isset($_POST['nombre'])){
		$nombre = $_POST['nombre'];
	}
	if(isset($_POST['tipo'])){
	    $tipo = $_POST['tipo'];
	    //echo $password;
	}
	if(isset($_POST['lugar'])){
		$lugar = $_POST['lugar'];
	}
	if(isset($_POST['descripcion'])){
		$descripcion = $_POST['descripcion'];
	}
	if(isset($_POST['fi'])){
		$fi = $_POST['fi'];
	}
	if(isset($_POST['ff'])){
		$ff = $_POST['ff'];
	}
	if(isset($_POST['monto'])){
		$monto = $_POST['monto'];
	}
	if(isset($_POST['descuento'])){
		$descuento = $_POST['descuento'];
	}
	if(isset($_POST['cantidad'])){
		$cantidad = $_POST['cantidad'];
	}

	if(isset($_POST['cmaxpersona'])){
		$cmaxpersona = $_POST['cmaxpersona'];
	}
	if(isset($_POST['imagen'])){
		$imagen = $_POST['imagen'];
	}
		
	if(isset($_POST['estado'])){
		$estado = $_POST['estado'];
	}

	if (isset($_FILES['archivo'])) {
	    $archivo = $_FILES['archivo'];
	    $extension = pathinfo($archivo['name'], PATHINFO_EXTENSION);
		$time = time();
	    $nombrei = "{$_POST['nombre_archivo']}_$time.$extension";
	    if (move_uploaded_file($archivo['tmp_name'], "../v/assets/img/$nombrei")) {
	        echo 1;
	    } else {
	        echo 0;
	    }
	}

	/*echo $nombre ;echo $tipo;echo $lugar ;echo $descripcion;echo $fi;echo $ff;echo $monto;echo $descuento;echo $cantidad;echo $cmaxpersona;
	print_r($nombrei);
	echo $estado;*/
}
// Instance of a User class
$userObject = new DB_Functions();

//----------------- REGISTRAR
if(empty($id) && empty($costoid) && !empty($nombre) && !empty($tipo) && !empty($lugar)&& !empty($descripcion) && !empty($fi)&& !empty($ff) && !empty($monto) && !empty($descuento) && !empty($cmaxpersona)&& !empty($cantidad)&& !empty($imagen)&& empty($estado)){
		
		$json_registration = $userObject->createCampamento($nombre ,$tipo,$lugar ,$descripcion,$fi,$ff,$monto,$descuento,$cantidad,$cmaxpersona,$imagen,$estado);
		echo $json_registration;
		//---------------- MOODIFICAR
	}elseif (!empty($id) && !empty($costoid)  && !empty($nombre) && !empty($tipo) && !empty($lugar)&& !empty($descripcion)&& !empty($fi) && !empty($ff) && !empty($monto) && !empty($descuento)&& !empty($cantidad) && !empty($cmaxpersona) && !empty($imagen) && empty($estado)) {
			$json_registration = $userObject-> updateCampamento($id,$costoid,$nombre,$tipo,$lugar ,$descripcion,$fi,$ff,$monto,$descuento,$cantidad,$cmaxpersona,$imagen,$estado);
		
		// ---------- ELIMINAR
		}elseif (!empty($id) && empty($nombre) && empty($tipo) && empty($lugar)&& empty($descripcion) && empty($fi)&& empty($ff) && empty($monto) && empty($descuento)&& empty($cantidad)&& empty($cmaxpersona)&& empty($imagen)&& empty($estado)) {
				$json_registration = $userObject-> deleteCampamento($id);
		}else{
	echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert"> <img src="../../gcm_chat/loader.gif"> Error de conexion al servidor</div></div>';
}



?>