﻿<?php
require_once 'm/db_functions.php';
    session_start();
    //if(isset ($_SESSION['id'])) {
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Bootstrap Admin Template : Binary Admin</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="v/assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="v/assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="v/assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="v/assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Inicio</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">  </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="v/assets/img/find_user.png" class="user-image img-responsive"/>
					</li>                   
					          <li  >
                        <a   href="v/login.php"><i class="fa fa-bolt "></i> Login</a>
                    </li>	
                    <li  >
                        <a   href="v/registeration.php"><i class="fa fa-laptop "></i> Registrarse</a>
                    </li>                    
                </ul>               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Lista de Campamentos</h2>   
                        <h5>Bienvendio aprecie nuestros campamentos y la ofertas.</h5>
                    </div>
                </div>              
                 <!-- /. ROW  -->
                <div class="row">
                    <div class="col-md-12" id="Form">
                         <?php
                         $demo = new DB_Functions();
                                                $users = $demo->ListCampametnos();
                                                $i=1;
                                                foreach ($users as $key => $user) {
                        ?>
                        <?php  //for($i=0; $i < 10;$i++) { ?>
                         <div class="col-xs-6 col-md-3">
                            <div class="thumbnail">
                              <img src="v/assets/img/batman.jpg" alt="...">
                              <div class="caption">
                                <h3><?= $user['nombre'] ?></h3>
                                <h5><?= $user['tipo_campamento'] ?></h5>
                                <!--h5><?= $user['descripcion'] ?></h5-->
                                <h5>de : <?= $user['fecha_inicio'] ?> hasta: <?= $user['fecha_final'] ?></h5>
                                <h5>Precio: <?= $user['monto'] ?></h5>
                                <h5>Descuento:<?= $user['descuento']?>% a las <?= $user['cantidad'] ?> primeros</h5>
                                <h5>Cupo: <?= $user['cupo_max'] ?> personas</h5>
                                <p><a href="v/registeration.php" class="btn btn-primary" role="button">Registrarse</a> <button class="btn btn-success" type="button" onClick="detallecampamentoini(<?= $user['campamento_id'] ?>)">Detalle</button></p>
                              </div>
                            </div>
                        </div>
                        <?php } ?>
                        

                    </div>
                </div>
                 <!-- /. END ROW  -->           
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="v/assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="v/assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="v/assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="v/assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="v/assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="v/assets/js/custom.js"></script>
    
    <script type="text/javascript" src="v/assets/js/ajax.js"></script>
    <script type="text/javascript" src="v/assets/js/validator.js"></script>
    
</body>
</html>
