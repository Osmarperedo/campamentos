<?php

class DB_Functions {

    private $conn;
   
    //Constructor
    function __construct() {
        require_once dirname(__FILE__) . '/db_connect.php';
        // opening db connection
        $db = new DbConnect();
        $this->conn = $db->connect();
    }
    // destructor
    function __destruct() {
    }

 
    public function loginUsers($username, $password){

        $stmt = $this->conn->prepare("SELECT u.usuario_id, p.nombre, p.apellido, up.perfil_id FROM usuario u, participante p,usuarios_perfiles up WHERE u.usuario = ?  AND u.passwrd = ? AND u.person_id = p.id_participante and u.deleted = 0 and up.usuario_id = u.usuario_id");
        $stmt->bind_param("ss", $username, $password);
        if ($stmt->execute()) {
            // $user = $stmt->get_result()->fetch_assoc();
            $stmt->bind_result($user_id, $nombre,$apellido,$perfil);
            $stmt->fetch();
            $user = array();
            // id
             $_SESSION['id'] =$user_id;
             $_SESSION['perfil'] =$perfil;
             $this->ini = 1;
            //Nombre
             $_SESSION['name']=$nombre;
            //Apellidos
             $_SESSION['apellido']=$apellido;

            $stmt->close();
            return $user;
        } else {
            return NULL;
        }
    }
    public function login($name, $pass) {
        if ($this->isloginExists($name,$pass)) {
                session_start();
                $this->loginUsers($name, $pass);
                header("Location: ../v/inicio.php");  
            } else {
                header("Location: ../index.php"); 
                
                //echo "Usuario y contraseña invalidos";
        }
        return;
    }
    private function isloginExists($name,$pass) {
        $stmt = $this->conn->prepare("SELECT * FROM usuario WHERE usuario = ? AND passwrd = ? and deleted=0 ");
        $stmt->bind_param("ss", $name,$pass);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }
    //----------------------------------USUARIOS --------------------
    public function listUsuarios(){
     $stmt = $this->conn->prepare("SELECT 
                                    a . *, b.id, b.nombre, fecha_registro, perfil_id,a.nombre as nombre_u
                                from
                                    (SELECT 
                                        u.usuario_id,
                                            u.usuario,
                                            u.created_at,
                                            if(u.deleted = 0, 'Habilitado', 'Deshabilitado') as deleted,
                                            ps . *
                                    from
                                        usuario u, participante ps
                                    where
                                        u.person_id = ps.id_participante
                                            and u.deleted = 0) a
                                        left join
                                    (select 
                                        *
                                    from
                                        perfiles p, usuarios_perfiles up
                                    where
                                        p.id = up.perfil_id) b ON a.usuario_id = b.usuario_id");
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    //------------------------------------------------------
    }
    public function listUsuariosid($id){
     $stmt = $this->conn->prepare("SELECT
                                    a.*, b .id,b.nombre,fecha_registro,perfil_id, a.nombre as nombre_u
                                from
                                    (SELECT 
                                        u.usuario_id, u.usuario, u.created_at, u.deleted, ps . *
                                    from
                                        usuario u, participante ps
                                    where
                                        u.person_id = ps.id_participante) a
                                        left join
                                    (select *
                                        
                                    from
                                        perfiles p, usuarios_perfiles up
                                    where
                                        p.id = up.perfil_id) b ON a.usuario_id = b.usuario_id
                                where a.usuario_id=?");
     $stmt->bind_param("s", $id);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    //------------------------------------------------------
    }
     // crear de nuevo usurio
    public function createUsuario($nombre ,$apellido,$celular ,$email,$direccion,$ci,$estado,$usu,$pass) {
        
        // First check if user already existed in db
        if (!$this->isPersonaExists($ci)) {
            if (!$this->isUsuarioExists($usu)) {
                $stmt = $this->conn->prepare("INSERT INTO participante (nombre,apellido,celular,email,direccion,ci) VALUES (?,?,?,?,?,?)");           
                $stmt->bind_param("ssssss", $nombre ,$apellido,$celular ,$email,$direccion,$ci);
                $stmt->execute();
                $person_id = $this->conn->insert_id;
                $stmt = $this->conn->prepare("INSERT INTO usuario (usuario, passwrd,person_id,deleted) values(?, ?,?,?)");
                $stmt->bind_param("ssss",$usu,$pass,$person_id,$estado);
                $result = $stmt->execute();
                $stmt->close();
                // Check for successful insertion
                if ($result) {
                    echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Registro Usuario Exitoso...</div></div>';
                } else {
                    
                    echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert">Error con el servidor Usuario no fue registrado intente nuevamente </div></div>';
                }
            }else{
                    echo '<div class="col-md-12"> <div class="alert alert-info" role="alert">Usuario ya se encuentra registrado favor ingresar un nombre de usuario diferente</div></div>';               
            }
        } else {
            echo '<div class="col-md-12"> <div class="alert alert-info" role="alert">Esta persona ya se encuentra registrada.</div></div>';               
        }

        return;
    }
    private function isPersonaExists($ci){
        $stmt = $this->conn->prepare("SELECT * from participante p where  p.ci= ? ");
        $stmt->bind_param("s", $ci);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }
    private function isUsuarioExists($usu){
        $stmt = $this->conn->prepare("SELECT * from usuario u where  u.usuario= ? ");
        $stmt->bind_param("s", $usu);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    } 


    public function updateUsuario($id,$nombre ,$apellido,$celular ,$email,$direccion,$ci,$estado) {
        $stmt = $this->conn->prepare("UPDATE participante SET nombre = ?, apellido = ?,celular = ?,email =?,direccion = ? ,ci=? where id_participante = (select person_id from usuario u where usuario_id=?)");
        $stmt->bind_param("sssssss", $nombre ,$apellido,$celular,$email,$direccion,$ci,$id);
        $stmt->execute();
        $stmt = $this->conn->prepare("UPDATE usuario SET deleted =? WHERE usuario_id =?");
        $stmt->bind_param("ss", $estado,$id);
        if ($stmt->execute()) {
             echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Modificacion con exito</div></div>';
            
        } else {
             echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert">Error al modificar los datos favor intente nuevamente</div></div>';
            //SS$stmt->error;
        }
        $stmt->close();
        return ;
    //------------------------------------------------------
    }   
    public function deleteUsuario($id) {
        $stmt = $this->conn->prepare("UPDATE usuario SET deleted =1 WHERE usuario_id =?");
        $stmt->bind_param("s", $id);
        if ($stmt->execute()) {
            echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Eliminación con exito</div></div>';
        } else {
            echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert">Error al eliminar los datos favor intente nuevamente</div></div>';
            $stmt->error;
        }
        $stmt->close();
        return ;
    //------------------------------------------------------
    }   
   
    //---------------------------------PERFIL---------------------
    public function listRol(){
     //$stmt = $this->conn->prepare("SELECT r.id, p.nombre,r.nombre as rnombre,r.fecha_registro, pr.* from perfiles p,usuarios_perfiles up ,recursos r,perfiles_recursos pr where r.id=pr.recurso_id and p.id=pr.perfil_id and p.id=up.perfil_id");     
       $stmt = $this->conn->prepare("SELECT * from perfiles ");
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
        /*$query = "SELECT * from perfiles";
     $result = @mysql_query($query);
     if (!$result) {return false;} else {return $result;} */
    //------------------------------------------------------
    }
    public function listRolid($id){
     //$stmt = $this->conn->prepare("SELECT r.id, p.nombre,r.nombre as rnombre,r.fecha_registro, pr.* from perfiles p,usuarios_perfiles up ,recursos r,perfiles_recursos pr where r.id=pr.recurso_id and p.id=pr.perfil_id and p.id=up.perfil_id");     
        $stmt = $this->conn->prepare("SELECT * from perfiles where id=?");
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    //------------------------------------------------------
    }
    public function listRolcheckid($id){
     /*$stmt = $this->conn->prepare("SELECT *, if(recurso_id is null,'','checked') as cbx from 
                                        (SELECT * from recursos) r
                                        left join
                                        (SELECT * from perfiles_recursos where perfil_id=?
                                        ) p on r.id=p.recurso_id ");     */
       $stmt = $this->conn->prepare("SELECT r.*, if (r.id is null,'','checked') as checked ,if (r.id is null,'','1') as permiso from 
                                        (SELECT * from recursos) r
                                        right join
                                        (SELECT * from perfiles_recursos where perfil_id=?
                                        ) p on r.id=p.recurso_id");


        $stmt->bind_param("s", $id);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    //------------------------------------------------------
    }

    public function listRolnocheckid($id){
        $stmt = $this->conn->prepare("SELECT DISTINCT (id), nombre from recursos where id not in (
                                        SELECT r.id from 
                                        (SELECT * from recursos) r
                                        right join
                                        (SELECT * from perfiles_recursos where perfil_id=?
                                        ) p on r.id=p.recurso_id)");

        $stmt->bind_param("s", $id);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    //------------------------------------------------------
    }

    public function createPerfil($nombre ) {
        if (!$this->isPerfilExists($nombre)) {
            $stmt = $this->conn->prepare("INSERT INTO perfiles(nombre) VALUES (?)");           
            $stmt->bind_param("s", $nombre);
            $result=$stmt->execute();

            $stmt->close();

            if ($result) {
                echo "Perfil registrado exitosamente";
            } else {
                echo "Error al registrar perfil intente nuevamente";
            }
        } else {
            echo "Perfil ya se encutra registrado";
        }

        return ;
    }
    private function isPerfilExists($nombre) {
        $stmt = $this->conn->prepare("SELECT * from perfiles where nombre=?");
        $stmt->bind_param("s", $nombre);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }

    public function updatePerfil($id,$nombre) {
        
        $stmt = $this->conn->prepare("UPDATE perfiles SET nombre=? 
            WHERE id=?");
        $stmt->bind_param("ss",$nombre,$id);

        if ($stmt->execute()) {
            echo "Modificación con exito perfil";
        } else {
            echo "Error al modificar los datos favor intente nuevamente";
            //$stmt->error;
        }
        $stmt->close();

        return ;
    }
    public function deletePerfil($id) {
        $stmt = $this->conn->prepare("UPDATE perfiles set estado =1 WHERE id=?");
        $stmt->bind_param("s",$id);

        if ($stmt->execute()) {
            echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Eliminacion con exito</div></div>';
        } else {
            echo "Error al eliminar favor intente nuevamente";
            $stmt->error;
        }
        $stmt->close();

        return ;
    }
    //---------------------------------ACCESOS---------------------
    public function listAcceos(){
     //$stmt = $this->conn->prepare("SELECT r.id, p.nombre,r.nombre as rnombre,r.fecha_registro, pr.* from perfiles p,usuarios_perfiles up ,recursos r,perfiles_recursos pr where r.id=pr.recurso_id and p.id=pr.perfil_id and p.id=up.perfil_id");     
        $stmt = $this->conn->prepare("SELECT * from recursos ");
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    //------------------------------------------------------
    }
    public function listAcceosid($id){
     //$stmt = $this->conn->prepare("SELECT r.id, p.nombre,r.nombre as rnombre,r.fecha_registro, pr.* from perfiles p,usuarios_perfiles up ,recursos r,perfiles_recursos pr where r.id=pr.recurso_id and p.id=pr.perfil_id and p.id=up.perfil_id");     
        $stmt = $this->conn->prepare("SELECT * from recursos where id=?");
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    //------------------------------------------------------
    }
    public function createAcceos($nombre ) {
        
        if (!$this->isAcceosExists($nombre)) {
                $stmt = $this->conn->prepare("INSERT INTO recursos (nombre) VALUES (?)");           
                $stmt->bind_param("s", $nombre);
                $result=$stmt->execute();

                $stmt->close();

                if ($result) {
                    echo "Acceso registrado exitosamente";
                } else {
                    echo "Error al registrar Acceso intente nuevamente";
                }
            } else {
                echo "Acceso ya se encutra registrado";
            }

            return ;
        }
        private function isAcceosExists($nombre) {
            $stmt = $this->conn->prepare("SELECT * from recursos where nombre=?");
            $stmt->bind_param("s", $nombre);
            $stmt->execute();
            $stmt->store_result();
            $num_rows = $stmt->num_rows;
            $stmt->close();
            return $num_rows > 0;
    }

    public function updateAcceos($id,$nombre) {
        
        $stmt = $this->conn->prepare("UPDATE recursos SET nombre=? 
            WHERE id=?");
        $stmt->bind_param("ss",$nombre,$id);

        if ($stmt->execute()) {
            echo "Modificación con exito Acceso";
        } else {
            echo "Error al modificar los datos favor intente nuevamente";
            //$stmt->error;
        }
        $stmt->close();

        return ;
    }
    public function deleteAcceos($id) {
        $stmt = $this->conn->prepare("UPDATE recursos set estado =1 WHERE id=?");
        $stmt->bind_param("s",$id);

        if ($stmt->execute()) {
            echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Eliminacion con exito</div></div>';
        } else {
            echo "Error al eliminar favor intente nuevamente";
            $stmt->error;
        }
        $stmt->close();

        return ;
    }
    // ----------------------------     PERFIL ACCCESO --------------
    public function createperfilacceso($idr,$idp) {
            $stmt = $this->conn->prepare("INSERT INTO perfiles_recursos (recurso_id,perfil_id)  
                    select r.id,p.id from recursos r,perfiles p where r.id in ($idr) and p.id=?");
            $stmt->bind_param("s",$idp);
            $result=$stmt->execute();
            $stmt->close();
            if ($result) {
                echo "Perfil - accesos registrado exitosamente";
            } else {
                echo "Error al registrar Perfil - accesos intente nuevamente";
            }
            return ;
    }
    //------------------------------------------ACCESO PERMISOS--------------
    public function listaccesocheckid($id){
        $stmt = $this->conn->prepare("SELECT 
                                        r . *,
                                        if(p.consultar = 1, 'checked', '') as consulta,
                                        if(p.editar = 1, 'checked', '') as editar,
                                        if(p.agregar = 1, 'checked', '') as agregar,
                                        if(p.eliminar = 1, 'checked', '') as eliminar,
                                        if(p.persmisousu =1, 'checked', '')as persmisousu,
                                        if(p.contrasena =1, 'checked', '') as contrasena,
                                        if(p.acceso =1, 'checked', '')  as acceso,
                                        if(p.permisorol =1, 'checked', '') as permisorol
                                    from
                                        (SELECT 
                                            *
                                        from
                                            recursos) r
                                            right join
                                        (SELECT 
                                            *
                                        from
                                            perfiles_recursos
                                        where
                                            perfil_id = ?) p ON r.id = p.recurso_id order by id");
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    //------------------------------------------------------
    }
    public function updatepermisoacceso($idp,$idr,$c,$r,$u,$d,$pu,$cn,$a,$pr){
        $together = array($c,$r,$u,$d,$idr,$pu,$cn,$a,$pr); 
        $cl = sizeof($c);
        for ($col = 0; $col <  $cl; $col++) {
            $stmt = $this->conn->prepare("UPDATE perfiles_recursos SET consultar=".$together[0][$col].",agregar =".$together[1][$col].", editar =".$together[2][$col].", eliminar= ".$together[3][$col].", persmisousu= ".$together[5][$col].",contrasena= ".$together[6][$col].",acceso= ".$together[7][$col].",permisorol= ".$together[8][$col]." WHERE recurso_id = ".$together[4][$col]." and perfil_id =?");
            $stmt->bind_param("s",$idp);
            $result=$stmt->execute();
        } 

        if ($result) {
            echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Operacion con exito</div></div>';
        } else {
            echo "Error al enviar los datos favor intente nuevamente";
            $stmt->error;
        }
        $stmt->close();

        return ;
    //------------------------------------------------------
    }
    public function createpermisousuario($id,$permiso) {
        
        if (!$this->ispermisoExists($id)) {
            $stmt = $this->conn->prepare("INSERT INTO usuarios_perfiles(usuario_id,perfil_id) VALUES (?,?);");           
            $stmt->bind_param("ss",$id,$permiso);
            $result=$stmt->execute();
            $stmt->close();

            if ($result) {
                echo "Permiso registrado exitosamente";
            } else {
                echo "Error al registrar permiso intente nuevamente";
            }
         } else {

            $stmt = $this->conn->prepare("UPDATE usuarios_perfiles SET perfil_id=? where usuario_id=?");
            $stmt->bind_param("ss",$permiso,$id);
            $result=$stmt->execute();
            $stmt->close();

            if ($result) {
                echo "Permiso registrado exitosamente";
            } else {
                echo "Error al registrar permiso intente nuevamente";
            }
        }

        return ;
    }
    private function ispermisoExists($id) {
        $stmt = $this->conn->prepare("SELECT * from usuarios_perfiles where usuario_id=?");
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }
    public function listpermisos($id){
     $stmt = $this->conn->prepare("SELECT * from  perfiles_recursos where perfil_id = (select 
                perfil_id From usuarios_perfiles where usuario_id = ?) order by recurso_id");
        $stmt->bind_param("s",$id);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function listperfrecurso($rec,$idu){
     $stmt = $this->conn->prepare("SELECT * FROM perfiles_recursos WHERE recurso_id = ? AND perfil_id =(SELECT perfil_id FROM usuarios_perfiles WHERE usuario_id = ?)     GROUP BY recurso_id");
        $stmt->bind_param("ss",$rec,$idu);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajes($idusu){
     $stmt = $this->conn->prepare("SELECT * from logmessages where de =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?))
            union all
            select * from logmessages where para =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?))");
        $stmt->bind_param("ss",$idusu,$idusu);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajeenviados($idusu){
     $stmt = $this->conn->prepare("SELECT * from logmessages where de =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?))");
        $stmt->bind_param("s",$idusu);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajerecibidos($idusu){
     $stmt = $this->conn->prepare("SELECT * from logmessages where para=(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?))");
        $stmt->bind_param("s",$idusu);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajeenviadoscel($idusu,$cel){
     $stmt = $this->conn->prepare("SELECT * from logmessages where de =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?)) and para =? ");
        $stmt->bind_param("ss",$idusu,$cel);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajerecibidoscel($idusu,$cel){
     $stmt = $this->conn->prepare("SELECT * from logmessages where de =? and para =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?))");
        $stmt->bind_param("ss",$cel,$idusu);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajefecha($idusu,$fecha){
     $stmt = $this->conn->prepare("SELECT * from logmessages where de =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?)) and date(created_at) = ?
        union all
        select * from logmessages where para =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?)) and date(created_at) =?");
                $stmt->bind_param("ssss",$idusu,$fecha,$idusu,$fecha);
                $stmt->execute();
                $tasks = $stmt->get_result();
                $stmt->close();
                return $tasks;   
    }
    public function ReporteMensajeenviadosfecha($idusu,$fecha){
     $stmt = $this->conn->prepare("SELECT * from logmessages where de =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?)) and date(created_at) = ? ");
        $stmt->bind_param("ss",$idusu,$fecha);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajerecibidosfecha($idusu,$fecha){
     $stmt = $this->conn->prepare("SELECT * from logmessages where para =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?)) and date(created_at) = ?");
        $stmt->bind_param("ss",$idusu,$fecha);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajeenviadosfechacel($idusu,$fecha,$cel){
     $stmt = $this->conn->prepare("SELECT * from logmessages where de =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?)) and para = ? and date(created_at) = ?");
        $stmt->bind_param("sss",$idusu,$cel,$fecha);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajerecibidosfechacel($idusu,$fecha,$cel){
     $stmt = $this->conn->prepare("SELECT * from logmessages where de =? and para =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?)) and date(created_at) = ?");
        $stmt->bind_param("sss",$cel,$idusu,$fecha);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajefechafecha($idusu,$fini,$ffin){
     $stmt = $this->conn->prepare("SELECT * from logmessages where de =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?)) and date(created_at) between ? and ?
        union all
        select * from logmessages where para =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?)) and date(created_at) between ? and ?");
        $stmt->bind_param("ssssss",$idusu,$fini,$ffin,$idusu,$fini,$ffin);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajeenviadosfechafecha($idusu,$fini,$ffin){
     $stmt = $this->conn->prepare("SELECT * from logmessages where de =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?)) and date(created_at) between ? and ?");
        $stmt->bind_param("sss",$idusu,$fini,$ffin);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajerecibidosfechafecha($idusu,$fini,$ffin){
     $stmt = $this->conn->prepare("SELECT * from logmessages where para =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?)) and date(created_at) between ? and ?");
        $stmt->bind_param("sss",$idusu,$fini,$ffin);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajeenvicelfechafecha($idusu,$fini,$ffin,$cell){
     $stmt = $this->conn->prepare("SELECT* from logmessages where de =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?)) and para =? and date(created_at) between ? and ?");
        $stmt->bind_param("ssss",$idusu,$cell,$fini,$ffin);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajereccelfechafecha($idusu,$fini,$ffin,$cell){
     $stmt = $this->conn->prepare("SELECT * from logmessages where de = ? and  para =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id=?)) and date(created_at) between ? and ?");
        $stmt->bind_param("ssss",$cel,$idusu,$fini,$ffin);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function ReporteMensajeenvreccelfechafecha($idusu,$fini,$ffin,$cell){
        $stmt = $this->conn->prepare("SELECT * from logmessages where de =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id= ? )) and para = ? and date(created_at) between ? and ? union all select * from logmessages where de= ? and para =(select telefono_p from persona where person_id=(select person_id from usuario where usuario_id= ? )) and date(created_at) between ? and ? ");
        $stmt->bind_param("ssssssss",$idusu,$cell,$fini,$ffin,$cell,$idusu,$fini,$ffin);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function resetUsuario($usu,$passw) {
       
        $stmt = $this->conn->prepare("UPDATE usuario SET password=? where nombre_u=?");
        $stmt->bind_param("ss", $passw,$usu);
        if ($stmt->execute()) {
             echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Modificacion reset con exito</div></div>';
        } else {
             echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert">Error al modificar los datos favor intente nuevamente</div></div>';
            //SS$stmt->error;
        }
        $stmt->close();
        return ;
    //------------------------------------------------------
    }   
    public function ListCampametnos(){
        $stmt = $this->conn->prepare("SELECT campamento_id,nombre,date(fecha_inicio) as fecha_inicio, date(fecha_final) as fecha_final, tipo_campamento,lugar,cupo_max,descripcion,imagen,estado,t.monto,descuento,cantidad FROM campamento c, costo t
            where c.idcosto=t.idcosto and c.estado=0");  
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function listCampametnosid($id){
     $stmt = $this->conn->prepare("SELECT     campamento_id,    t.idcosto,    nombre,    date(fecha_inicio) as fecha_inicio,   date(fecha_final) as fecha_final,    tipo_campamento,    lugar,    cupo_max,    descripcion,   imagen,    estado,    t.monto,    descuento,    cantidad,    DATE(SYSDATE()) as fechapago,    count(*) as numper,    c.campamento_id FROM   campamento c,costo t where    c.idcosto = t.idcosto        and campamento_id = ? group by campamento_id");
     $stmt->bind_param("s", $id);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    //------------------------------------------------------
    }

    public function createCampamento($nombre ,$tipo,$lugar ,$descripcion,$fi,$ff,$monto,$descuento,$cantidad,$cmaxpersona,$imagen,$estado) {
            if (!$this->isCampamentoExists($nombre)) {
                $stmt = $this->conn->prepare("INSERT INTO costo (monto,descuento,cantidad) VALUES(?,?,?);");           
                $stmt->bind_param("sss", $monto ,$descuento,$cantidad);
                $stmt->execute();
                $costoid = $this->conn->insert_id;
                $stmt = $this->conn->prepare("INSERT INTO campamento (nombre,fecha_inicio,fecha_final,tipo_campamento,lugar,cupo_max,descripcion,imagen,estado,idcosto) VALUES(?,?,?,?,?,?,?,?,?,?);");
                $stmt->bind_param("ssssssssss",$nombre ,$fi,$ff,$tipo,$lugar,$cmaxpersona,$descripcion,$imagen,$estado,$costoid);
                $result = $stmt->execute();
                $stmt->close();
                // Check for successful insertion
                if ($result) {
                    echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Registro Campamento Exitoso...</div></div>';
                } else {
                    
                    echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert">Error con la conexion el servidor no fue registrado intente nuevamente </div></div>';
                }
            }else{
                    echo '<div class="col-md-12"> <div class="alert alert-info" role="alert">Campamento ya se encuentra registrado favor ingresar un nuenvo nombre de campamento diferente</div></div>';               
            }
            return;
    }
    private function isCampamentoExists($nombre){
        $stmt = $this->conn->prepare("SELECT * FROM campamento where nombre=?");
        $stmt->bind_param("s", $nombre);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    } 
    public function updateCampamento($id,$costoid,$nombre,$tipo,$lugar ,$descripcion,$fi,$ff,$monto,$descuento,$cantidad,$cmaxpersona,$imagen,$estado) {
        $stmt = $this->conn->prepare("UPDATE costo SET monto = ?,descuento = ?,cantidad =? WHERE idcosto = ?");
        $stmt->bind_param("ssss",$monto,$descuento,$cantidad,$costoid);
        $stmt->execute();
        $stmt = $this->conn->prepare("UPDATE campamento SET nombre = ?,fecha_inicio = ?,fecha_final = ?,tipo_campamento = ?,lugar = ?,cupo_max = ?,descripcion = ?,imagen = ?,estado = ? WHERE campamento_id = ?;");
        $stmt->bind_param("ssssssssss",$nombre,$fi,$ff,$tipo,$lugar,$cmaxpersona ,$descripcion,$imagen,$estado,$id);
        if ($stmt->execute()) {
             echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Modificacion con exito</div></div>';
            
        } else {
             echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert">Error conla conexion al servidor al  modificar los datos favor intente nuevamente</div></div>';
            //SS$stmt->error;
        }
        $stmt->close();
        return ;
    //------------------------------------------------------
    }   
    public function deleteCampamento($id) {
        $stmt = $this->conn->prepare("UPDATE campamento SET estado=1 WHERE campamento_id=? ");
        $stmt->bind_param("s", $id);
        if ($stmt->execute()) {
            echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Eliminación con exito</div></div>';
        } else {
            echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert">Error en la conexion al servidor al eliminar los datos favor intente nuevamente</div></div>';
            $stmt->error;
        }
        $stmt->close();
        return ;
    //------------------------------------------------------
    }   


//----------------------------------PARTICIPANTE --------------------
    public function listParticipante(){
     $stmt = $this->conn->prepare("SELECT 
                                    a . *, b.id, b.nombre, fecha_registro, perfil_id,a.nombre as nombre_u
                                from
                                    (SELECT 
                                        u.usuario_id,
                                            u.usuario,
                                            u.created_at,
                                            if(u.deleted = 0, 'Habilitado', 'Deshabilitado') as deleted,
                                            ps . *
                                    from
                                        usuario u, participante ps
                                    where
                                        u.person_id = ps.id_participante
                                            and u.deleted = 0) a
                                        left join
                                    (select 
                                        *
                                    from
                                        perfiles p, usuarios_perfiles up
                                    where
                                        p.id = up.perfil_id) b ON a.usuario_id = b.usuario_id");
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    //------------------------------------------------------
    }
    public function listParticipanteid($id){
     $stmt = $this->conn->prepare("SELECT
                                    a.*, b .id,b.nombre,fecha_registro,perfil_id, a.nombre as nombre_u
                                from
                                    (SELECT 
                                        u.usuario_id, u.usuario, u.created_at, u.deleted, ps . *
                                    from
                                        usuario u, participante ps
                                    where
                                        u.person_id = ps.id_participante) a
                                        left join
                                    (select *
                                        
                                    from
                                        perfiles p, usuarios_perfiles up
                                    where
                                        p.id = up.perfil_id) b ON a.usuario_id = b.usuario_id
                                where a.usuario_id=?");
     $stmt->bind_param("s", $id);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    //------------------------------------------------------
    }
     // crear de nuevo usurio
    public function createParticipante($nombre,$apellido,$telefono,$celular,$email,$direccion,$ci,$iglesia,$usu,$pass) {
        
        // First check if user already existed in db
        if (!$this->isParticipanteExists($ci)) {
            if (!$this->isUsuaExists($usu)) {
                $stmt = $this->conn->prepare("INSERT INTO participante (nombre,apellido,telefono,celular,email,direccion,ci,iglesia) VALUES(?,?,?,?,?,?,?,?);");           
                $stmt->bind_param("ssssssss", $nombre ,$apellido,$telefono,$celular,$email,$direccion,$ci,$iglesia);
                $stmt->execute();
                $person_id = $this->conn->insert_id;
                $stmt = $this->conn->prepare("INSERT INTO usuario (usuario,passwrd,person_id,deleted) VALUES (?,?,?,0);");
                $stmt->bind_param("sss",$usu,$pass,$person_id);
                $stmt->execute();
                $usuario_id = $this->conn->insert_id;
                $stmt = $this->conn->prepare("INSERT INTO usuarios_perfiles (usuario_id,perfil_id) VALUES (?,2);");
                $stmt->bind_param("s",$usuario_id);
                $result = $stmt->execute();
                $stmt->close();
                // Check for successful insertion
                if ($result) {
                    echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Registro Usuario Exitoso...</div></div><br/><a href="login.php" >Login here</a>';
                } else {
                    
                    echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert">Error con el servidor Usuario no fue registrado intente nuevamente </div></div>';
                }
            }else{
                    echo '<div class="col-md-12"> <div class="alert alert-info" role="alert">Usuario ya se encuentra registrado favor ingresar un nombre de usuario diferente</div></div>';               
            }
        } else {
            echo '<div class="col-md-12"> <div class="alert alert-info" role="alert">Esta persona ya se encuentra registrada.</div></div>';               
        }

        return;
    }
    private function isParticipanteExists($ci){
        $stmt = $this->conn->prepare("SELECT * from participante p where  p.ci= ? ");
        $stmt->bind_param("s", $ci);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }
    private function isUsuaExists($usu){
        $stmt = $this->conn->prepare("SELECT * from usuario u where  u.usuario= ? ");
        $stmt->bind_param("s", $usu);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    } 
    public function updateParticipante($id,$nombre ,$apellido,$celular ,$email,$direccion,$ci,$estado) {
        $stmt = $this->conn->prepare("UPDATE persona SET nombre_p = ?,apellido_p = ?,telefono_p = ?,email =?,direccion = ?,ci = ? WHERE  person_id = (select person_id from usuario u where usuario_id=?)");
        $stmt->bind_param("sssssss", $nombre ,$apellido,$celular ,$email,$direccion,$ci,$id);
        $stmt->execute();
        $stmt = $this->conn->prepare("UPDATE usuario SET deleted =? WHERE usuario_id =?");
        $stmt->bind_param("ss", $estado,$id);
        if ($stmt->execute()) {
             echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Modificacion con exito</div></div>';
            
        } else {
             echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert">Error al modificar los datos favor intente nuevamente</div></div>';
            //SS$stmt->error;
        }
        $stmt->close();
        return ;
    //------------------------------------------------------
    }   
    public function deleteParticipante($id) {
        $stmt = $this->conn->prepare("UPDATE usuario SET deleted =1 WHERE usuario_id =?");
        $stmt->bind_param("s", $id);
        if ($stmt->execute()) {
            echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Eliminación con exito</div></div>';
        } else {
            echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert">Error al eliminar los datos favor intente nuevamente</div></div>';
            $stmt->error;
        }
        $stmt->close();
        return ;
    //------------------------------------------------------
    }   

    //------------- registro pago ----------

    public function createregistropago($idp,$idc,$fi,$fp,$monto) {
        
        // First check if user already existed in db
                $stmt = $this->conn->prepare("INSERT INTO pago (monto) VALUES (?);");           
                $stmt->bind_param("s",$monto);
                $stmt->execute();
                $pago_id = $this->conn->insert_id;
                $stmt = $this->conn->prepare("INSERT INTO registro (idparticipante,idcampamento,idpago,fecha_inscripcion,fecha_pago) VALUES( (SELECT 
            id_participante
        FROM
            participante p,
            usuario u
        where
            p.id_participante = u.person_id
                and u.usuario_id = ?),?,?,?,?);");
                $stmt->bind_param("sssss",$idp ,$idc,$pago_id,$fi ,$fp);
                $result = $stmt->execute();
                $stmt->close();
                // Check for successful insertion
                if ($result) {
                    echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Registro Exitoso...</div></div><br/>';
                } else {
                    
                    echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert">Error con el servidor no fue registrado intente nuevamente </div></div>';
                }
        return;
    }

    public function listaRegistros() {
        
        $stmt = $this->conn->prepare("SELECT campamento_id,t.idcosto,nombre,date(fecha_inicio) as fecha_inicio,date(fecha_final) as fecha_final,tipo_campamento,lugar,cupo_max,t.monto,descuento,cantidad,DATE(SYSDATE()) as fechapago,count(*) as numper FROM campamento c, costo t, registro r where c.idcosto = t.idcosto and r.idcampamento= c.campamento_id group by idcampamento");
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function listaRegistrosparti($id) {
        
        $stmt = $this->conn->prepare("SELECT campamento_id,t.idcosto,nombre,date(fecha_inicio) as fecha_inicio,date(fecha_final) as fecha_final,tipo_campamento,lugar,cupo_max,t.monto,descuento,cantidad,DATE(SYSDATE()) as fechapago,count(*) as numper FROM campamento c, costo t, registro r where c.idcosto = t.idcosto and r.idcampamento = c.campamento_id and idparticipante = (SELECT id_participante FROM participante p,usuario u where p.id_participante = u.person_id and u.usuario_id = ?) group by idcampamento");
        $stmt->bind_param("s",$id);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function listaiscritospago($id) {
        
        $stmt = $this->conn->prepare("SELECT r.fecha_inscripcion,r.fecha_pago,p.nombre,p.apellido,p.iglesia,g.monto,g.imagen ,g.idpago from registro r , participante p, campamento c,pago g where p.id_participante=r.idparticipante and r.idcampamento=c.campamento_id and r.idpago=g.idpago and r.idcampamento=?");
        $stmt->bind_param("s",$id);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }
    public function listapagos() {
        
        $stmt = $this->conn->prepare("SELECT r.fecha_inscripcion,r.fecha_pago,p.nombre,p.apellido,p.iglesia,g.monto,g.imagen ,g.idpago from registro r , participante p, campamento c,pago g where p.id_participante=r.idparticipante and r.idcampamento=c.campamento_id and r.idpago=g.idpago");
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }

    public function listapagosparti($id) {
        
        $stmt = $this->conn->prepare("SELECT r.fecha_inscripcion,r.fecha_pago,p.nombre,p.apellido,p.iglesia,g.monto,g.imagen,g.idpago from registro r,participante p,campamento c,pago g where p.id_participante = r.idparticipante and r.idcampamento = c.campamento_id and r.idpago = g.idpago and idparticipante = (SELECT id_participante FROM participante p,usuario u where p.id_participante = u.person_id and u.usuario_id = ?)");
        $stmt->bind_param("s",$id);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }

     public function realizarpagosver($id) {
        
        $stmt = $this->conn->prepare("SELECT r.fecha_inscripcion,r.fecha_pago,p.nombre,p.apellido,p.iglesia,g.monto,g.imagen,c.campamento_id,g.idpago  from registro r , participante p, campamento c,pago g where p.id_participante=r.idparticipante and r.idcampamento=c.campamento_id and r.idpago=g.idpago and g.idpago=?");
        $stmt->bind_param("s",$id);
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }


    public function pagorealizado($idp ,$monto,$imagen) {
        $stmt = $this->conn->prepare("UPDATE pago SET monto =?,imagen = ? WHERE idpago= ?;");
        $stmt->bind_param("sss", $monto,$imagen,$idp);
        if ($stmt->execute()) {
            echo '<div class="col-md-12"> <div class="alert alert-success" role="alert">Pago realizado con exito</div></div>';
        } else {
            echo '<div class="col-md-12"> <div class="alert alert-danger" role="alert">Error intentar comfirmar el pago, intente nuevamente</div></div>';
            $stmt->error;
        }
        $stmt->close();
        return ;
    //------------------------------------------------------
    }   

  public function reportegeneral() {
        
        $stmt = $this->conn->prepare("SELECT 
    c.nombre as nombrec,
    c.tipo_campamento,
    c.cupo_max,
    p.nombre,
    p.apellido,
    p.celular,
    p.iglesia,
    g.monto,
ct.descuento,
ct.cantidad,
    if(g.imagen is null,'Pendiente','Realizado') as estado,
    date(r.fecha_inscripcion) as fecha_inscripcion,
    date(r.fecha_pago) as fecha_pago
from
    registro r,
    participante p,
    campamento c,
    pago g,costo ct
where
    p.id_participante = r.idparticipante
        and r.idcampamento = c.campamento_id
        and r.idpago = g.idpago
and c.idcosto=ct.idcosto");
        $stmt->execute();
        $tasks = $stmt->get_result();
        $stmt->close();
        return $tasks;   
    }



}

 
?>
