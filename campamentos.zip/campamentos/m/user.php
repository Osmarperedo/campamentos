<?php
class User{
	
	private $db;
		
	public function __construct(){
		include_once './db_connect.php';
        // connecting to database
        $this->db = new DB_Connect();
        $this->db->connect();
	}
	
	public function loginUsers($username, $password){
		$result = mysql_query("SELECT u.person_id, u.tipo,CONCAT(p.nombre_p,' ',p.apellido_p) as nombre FROM usuario u,persona p WHERE u.usuarionombre = '$username' AND u.password = '$password' AND u.person_id = p.person_id");

		if(mysql_num_rows($result) > 0){
            return $result;
        }else{
            
            return $result;
        }
		
	}
	
	public function isUsuarioExist($username){		
				
		$query = "select * from usuario where usuarionombre = '$username' Limit 1";
		$result = mysql_query($query);
		if(mysql_num_rows($result) > 0){
			return true;
		}		
		return false;		
	}

	public function isEmailExist($email){		
				
		$query = "select * from persona where email = '$email' Limit 1";
		$result = mysql_query($query);
		if(mysql_num_rows($result) > 0){
			return true;
		}		
		return false;		
	}
	
	public function isEmailUsuarioExist($email){		
				
		$query = "select * from usuario where person_id =(select person_id from persona where email ='$email') Limit 1";
		$result = mysql_query($query);
		if(mysql_num_rows($result) > 0){
			return true;
		}		
		return false;		
	}

	public function createNewRegisterUser($username, $password, $email,$imei){
			
			
		$canemailExist = $this->isEmailExist($email);
		if($canemailExist){
			$canUserExist = $this->isUsuarioExist($username);
			if($canUserExist){	
				echo "Este usuario ya se encuentra registrado";
			}else{

				$canUserEmailExist = $this->isEmailUsuarioExist($email);
				if($canUserEmailExist){	
					echo "Esta persona ya se encuentra registrado..";
				}else{
					
					$inserted = mysql_query("INSERT INTO usuario (usuarionombre, password,person_id, deleted,tipo,imei) VALUES ('$username','$password',(select person_id from persona where email = '$email' ) ,'',(select if(comments='alumno',1,2) as tipo from persona where email = '$email' ),'$imei')");
					if($inserted==1)
					{ 
						echo "Usuario registrado Exitosamente";	
				 	}else{ 
				  		echo "Usuario no registrado"; 
				  	}		
				}		
			}
		}else{
			echo "Este Email ingresado no existe ingrese nuevamente";
		}	
				
	}	
}

?>