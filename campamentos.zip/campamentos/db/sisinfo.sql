-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2016 at 04:01 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sisinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `campamento`
--

CREATE TABLE `campamento` (
  `campamento_id` int(11) NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_inicio` timestamp NULL DEFAULT NULL,
  `fecha_final` timestamp NULL DEFAULT NULL,
  `tipo_campamento` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `lugar` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cupo_max` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `descripcion` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `imagen` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `estado` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `idcosto` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `campamento`
--

INSERT INTO `campamento` (`campamento_id`, `nombre`, `fecha_inicio`, `fecha_final`, `tipo_campamento`, `lugar`, `cupo_max`, `descripcion`, `imagen`, `estado`, `idcosto`) VALUES
(1, 'chapare', '2016-06-12 04:00:00', '2016-06-18 04:00:00', 'juvenil', 'cochabamba -chapare', '70', 'Bueno, hace un tiempo publiquÃ© un posteo en ', 'C:\\fakepath\\batman.jpg', '0', '1'),
(2, 'cerro rico', '2016-06-12 04:00:00', '2016-06-18 04:00:00', 'familia', 'potosi', '50', 'Bueno, hace un tiempo publiquÃ© un posteo en ', 'C:\\fakepath\\batman.jpg', '0', '2');

-- --------------------------------------------------------

--
-- Table structure for table `costo`
--

CREATE TABLE `costo` (
  `idcosto` int(11) NOT NULL,
  `monto` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `descuento` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `costo`
--

INSERT INTO `costo` (`idcosto`, `monto`, `descuento`, `cantidad`) VALUES
(1, '700', '5', 6),
(2, '700', '5', 5);

-- --------------------------------------------------------

--
-- Table structure for table `pago`
--

CREATE TABLE `pago` (
  `idpago` int(11) NOT NULL,
  `monto` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `imagen` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `pago`
--

INSERT INTO `pago` (`idpago`, `monto`, `imagen`) VALUES
(1, '665', NULL),
(2, '665', NULL),
(3, '665', NULL),
(4, '665', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `participante`
--

CREATE TABLE `participante` (
  `id_participante` int(11) NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `apellido` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `telefono` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `celular` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `ci` int(11) NOT NULL,
  `iglesia` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `participante`
--

INSERT INTO `participante` (`id_participante`, `nombre`, `apellido`, `telefono`, `celular`, `email`, `direccion`, `ci`, `iglesia`) VALUES
(1, 'Abner', 'Salinas choque', '12345678', '87654321', 'a@gmail.com', 'Av. Blanco galindo', 0, 'Critiana 1'),
(16, 'wendel', 'torrico', '55555555', '66666666', 'ab@gmail.com', 'av ,vilazon', 99999999, 'Cristina sagradad familia'),
(17, 'saul', 'mogro', '33333333', '22222222', 's@gmail.com', 'av. blanco galindo Km5', 22222222, 'catolica');

-- --------------------------------------------------------

--
-- Table structure for table `perfiles`
--

CREATE TABLE `perfiles` (
  `id` int(11) NOT NULL COMMENT 'llave primaria de la tabla',
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'Descripción del perfil',
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'fecha de registro'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `perfiles`
--

INSERT INTO `perfiles` (`id`, `nombre`, `fecha_registro`) VALUES
(1, 'Administrador', '2016-04-19 02:48:03'),
(2, 'visitante', '2016-04-19 02:48:03');

-- --------------------------------------------------------

--
-- Table structure for table `perfiles_recursos`
--

CREATE TABLE `perfiles_recursos` (
  `consultar` tinyint(1) DEFAULT '0',
  `agregar` tinyint(1) DEFAULT '0',
  `editar` tinyint(1) DEFAULT '0',
  `eliminar` tinyint(1) DEFAULT '0',
  `persmisousu` tinyint(1) DEFAULT '0',
  `contrasena` tinyint(1) DEFAULT '0',
  `acceso` tinyint(1) DEFAULT '0',
  `permisorol` tinyint(1) DEFAULT '0',
  `recurso_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  `idpr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `perfiles_recursos`
--

INSERT INTO `perfiles_recursos` (`consultar`, `agregar`, `editar`, `eliminar`, `persmisousu`, `contrasena`, `acceso`, `permisorol`, `recurso_id`, `perfil_id`, `idpr`) VALUES
(1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1),
(1, 1, 1, 1, 1, 1, 0, 0, 2, 1, 2),
(1, 1, 1, 1, 0, 0, 0, 0, 3, 1, 3),
(1, 1, 1, 1, 0, 0, 0, 0, 4, 1, 4),
(1, 1, 1, 1, 0, 0, 0, 0, 5, 1, 5),
(1, 1, 1, 1, 0, 0, 0, 0, 6, 1, 6),
(1, 1, 1, 1, 0, 0, 0, 0, 7, 1, 7),
(1, 1, 0, 0, 0, 0, 0, 0, 4, 2, 8),
(1, 1, 0, 0, 0, 0, 0, 0, 5, 2, 9);

-- --------------------------------------------------------

--
-- Table structure for table `recursos`
--

CREATE TABLE `recursos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL COMMENT 'nombre del recurso',
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Fecha en la que se registro el recurso'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `recursos`
--

INSERT INTO `recursos` (`id`, `nombre`, `fecha_registro`) VALUES
(1, 'Gestion Roles', '2016-04-19 02:48:48'),
(2, 'Gestion Usuarios', '2016-04-19 02:48:48'),
(3, 'Gestion campamentos', '2016-04-19 02:51:42'),
(4, 'Gestion registros', '2016-04-19 02:51:42'),
(5, 'Gestion pagos', '2016-04-19 02:53:09'),
(6, 'Reportes', '2016-04-19 02:53:09'),
(7, 'Gestionar Acceso', '2016-04-25 22:23:56');

-- --------------------------------------------------------

--
-- Table structure for table `registro`
--

CREATE TABLE `registro` (
  `idregistro` int(11) NOT NULL,
  `idparticipante` int(11) DEFAULT NULL,
  `idcampamento` int(11) DEFAULT NULL,
  `idpago` int(11) DEFAULT NULL,
  `fecha_inscripcion` timestamp NULL DEFAULT NULL,
  `fecha_pago` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `registro`
--

INSERT INTO `registro` (`idregistro`, `idparticipante`, `idcampamento`, `idpago`, `fecha_inscripcion`, `fecha_pago`) VALUES
(1, 16, 1, 4, '2016-06-12 04:00:00', '2016-06-12 04:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

CREATE TABLE `usuario` (
  `usuario_id` int(10) NOT NULL,
  `usuario` varchar(255) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `passwrd` varchar(255) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `person_id` int(10) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`usuario_id`, `usuario`, `passwrd`, `created_at`, `person_id`, `deleted`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2016-05-28 03:51:26', 1, 0),
(14, 'wendel', 'b1bdd80eb9efab5a05c64c65213975fe', '2016-06-12 12:14:10', 16, 0),
(15, 'saul', '4b2b772a039e1f20612cc32a5b633bce', '2016-06-12 12:14:58', 17, 0);

-- --------------------------------------------------------

--
-- Table structure for table `usuarios_perfiles`
--

CREATE TABLE `usuarios_perfiles` (
  `usuario_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  `idup` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `usuarios_perfiles`
--

INSERT INTO `usuarios_perfiles` (`usuario_id`, `perfil_id`, `idup`) VALUES
(1, 1, 1),
(14, 2, 13),
(15, 2, 14);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `campamento`
--
ALTER TABLE `campamento`
  ADD PRIMARY KEY (`campamento_id`);

--
-- Indexes for table `costo`
--
ALTER TABLE `costo`
  ADD PRIMARY KEY (`idcosto`);

--
-- Indexes for table `pago`
--
ALTER TABLE `pago`
  ADD PRIMARY KEY (`idpago`);

--
-- Indexes for table `participante`
--
ALTER TABLE `participante`
  ADD PRIMARY KEY (`id_participante`);

--
-- Indexes for table `perfiles`
--
ALTER TABLE `perfiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `perfiles_recursos`
--
ALTER TABLE `perfiles_recursos`
  ADD PRIMARY KEY (`idpr`);

--
-- Indexes for table `recursos`
--
ALTER TABLE `recursos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registro`
--
ALTER TABLE `registro`
  ADD PRIMARY KEY (`idregistro`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`usuario_id`);

--
-- Indexes for table `usuarios_perfiles`
--
ALTER TABLE `usuarios_perfiles`
  ADD PRIMARY KEY (`idup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `campamento`
--
ALTER TABLE `campamento`
  MODIFY `campamento_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `costo`
--
ALTER TABLE `costo`
  MODIFY `idcosto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `pago`
--
ALTER TABLE `pago`
  MODIFY `idpago` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `participante`
--
ALTER TABLE `participante`
  MODIFY `id_participante` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `perfiles`
--
ALTER TABLE `perfiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'llave primaria de la tabla', AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `perfiles_recursos`
--
ALTER TABLE `perfiles_recursos`
  MODIFY `idpr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `recursos`
--
ALTER TABLE `recursos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `registro`
--
ALTER TABLE `registro`
  MODIFY `idregistro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `usuario_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `usuarios_perfiles`
--
ALTER TABLE `usuarios_perfiles`
  MODIFY `idup` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
