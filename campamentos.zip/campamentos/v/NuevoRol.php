                <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           NUEVO PERFIL
                        </div>
                        <div class="panel-body">
                          <form name="nuevo_rol" method="POST" action="" onSubmit="insertperfil(); return false">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Nombre rol</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Enter rol"  onkeypress="return soloLetras(event)"  required />
                              </div>
                              <button type="submit" class="btn btn-default">Submit</button>
                          </form>
                            </div>
                        </div>
                    </div>
                </div>
