<?php
require_once '../m/db_functions.php';
$id=$_POST['id'];
 $demo = new DB_Functions();
  $users = $demo->listRolid($id);
  foreach ($users as $key => $user) {

?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           EDITAR PERFIL
                        </div>
                        <div class="panel-body">
                          <form name="editperfil" method="POST" action="" onSubmit="modificarperfil(); return false">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Nombre rol</label>
                                <input type="hidden" class="form-control" id="id" name="id" placeholder="Enter rol" value="<?= $user['id'] ?>" />
                                <input style="text-transform:capitalize;" type="text" class="form-control" id="nombre" name="nombre" placeholder="Enter rol" value="<?= $user['nombre'] ?>" onkeypress="return soloLetras(event)" required/>
                              </div>
                              <button type="submit" class="btn btn-default">Submit</button>
                          </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
}
?>