

                  <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                          <div class="panel-heading">
                              NUEVA CAMPAMENTO
                          </div>
                        <div class="panel-body">
                           <form  id="nuevo_campamento" name="nuevo_campamento" method="POST" action="javascript:void(0);" onSubmit="insertcampamento(); return false" >
                              <div class="form-group">
                                <label for="nombre" class="control-label">Nombre *</label>
                                <input style="text-transform:capitalize;" type="text" class="form-control" name="nombre" id="nombre" placeholder="Enter nombre" onkeypress="return soloLetras(event)" required/>
                              </div>
                              <div class="form-group">
                                <label for="tipo">Tipo *</label>
                                <input style="text-transform:capitalize;" type="text" class="form-control" name="tipo"id="tipo" placeholder="Enter apellido"  required/>                            
                              </div>
                              <div class="form-group">
                                <label for="lugar">Lugar *</label>
                                <input style="text-transform:capitalize;" type="text" class="form-control" name="lugar"id="lugar" placeholder="Enter apellido" required/>                            
                              </div>
                              <div class="form-group">
                                <label for="descripcion">Descripcion *</label>
                                <textarea style="text-transform:capitalize;" class="form-control" rows="3" name="descripcion"id="descripcion"placeholder="Enter Descripción" required></textarea>
                                                            
                              </div>
                              <div class="form-group">
                                <label for="fi">Fecha inicio *</label>
                                <input class="form-control" type="date" id="fi" name="fi" required>
                              </div>
                              <div class="form-group">
                                <label for="ff">Fecha Final *</label>
                                <input class="form-control" type="date" id="ff" name="ff" required>
                              </div>
                              <div class="form-group">
                              <label for="monto">Monto *</label>
                              <div class="form-group input-group">
                                <span class="input-group-addon">Bs.</span>
                                <input type="text" class="form-control" name="monto" id="monto" onkeypress="return isNumberKey(event)"/>
                                <span class="input-group-addon">.00</span>
                              </div>
                              </div>
                              <div class="form-group">
                                <label for="descuento">Descuento *</label>
                                <div class="form-group input-group">                              
                                <input type="text" class="form-control" name="descuento" id="descuento" placeholder="Enter descuento" onkeypress="return isNumberKey(event)" />
                                <span class="input-group-addon">%</span>
                                </div>
                              </div>
                              <div class="form-group">
                                    <label for="cantidad">Cantidad de inscritos con descuento*</label>
                                    
                                    <input type="text" class="form-control" name ="cantidad" id="cantidad" placeholder="Enter cantidad"  onkeypress="return isNumberKey(event)" required/>                                
                                    
                                    
                              </div>
                              <div class="form-group">
                                    <label for="cmaxpersona">Cantidad Max de Personas *</label>
                                    <input type="text" class="form-control" name ="cmaxpersona" id="cmaxpersona" placeholder="Enter Cantidad max personas"  onkeypress="return isNumberKey(event)" required/>                                
                              </div>
                              <div class="form-group">
                                    <label for="imagen">Imagen *</label>
                                    <input type="file" name="imagen" id="imagen" />
                              </div>

                              
                              <div class="form-group">
                                                <label>Estado *</label>
                                                <select class="form-control" name="estado" required>
                                                    <option value="">Elija una opcion</option>
                                                    <option value="0">Activo</option>
                                                    <option value="1">Suspenso</option>
                                                </select>
                              </div>
                                 <button type="submit" id="boton_subir" class="btn btn-primary" >Guardar</button>
                            </form>
                        </div>
                        </div>
                    </div>
                   </div>

   