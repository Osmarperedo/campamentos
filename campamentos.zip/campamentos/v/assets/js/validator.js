function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
 
         return true;
      }

function isAlphanumeric(str){
    var validate = document.getElementById(str).value;
    if( /[^a-zA-Z0-9]/.test( validate ) ) {
       //alert('Input is not alphanumeric');
       return false;
    }
    return true;
}

function soloLetras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toLowerCase();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyz";
    especiales = [8, 37, 39, 46];

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }
    }

    if(letras.indexOf(tecla) == -1 && !tecla_especial)
        return false;
}

function validar(esto){ 
  valido=false; 
  for(a=0;a<esto.elements.length;a++){ 
    if(esto[a].type=="checkbox" && esto[a].checked==true){ 
      valido=true; 
      break 
    } 
  } 
  if(!valido){ 
    alert("Chequee una casilla!");return false 
  } 

} 

/*function limpia() {
    var val = document.getElementById("miInput").value;
    var tam = val.length;
    for(i = 0; i < tam; i++) {
        if(!isNaN(val[i]))
            document.getElementById("miInput").value = '';
    }
}*/
