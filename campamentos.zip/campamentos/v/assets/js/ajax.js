// JavaScript Document

function objetoAjax(){
	var xmlhttp=false;
	try {
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	} catch (e) {
		try {
		   xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		} catch (E) {
			xmlhttp = false;
  		}
	}

	if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
		xmlhttp = new XMLHttpRequest();
	}
	return xmlhttp;
}
// ------------- USUARIO ----------------------
function nuevousuario(){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('Form');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "NuevoUsuario.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send()
}
function editarusuario(usuario_id){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('Form');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "EditarUsuario.php");
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
	        Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("usuario_id="+usuario_id)
}
function insertarusuario(){
	//donde se mostrará el formUsu con los datos
	//Form = document.getElementById('Form');
	nombrep=document.nuevo_usuario.nombrep.value;
	apellidop=document.nuevo_usuario.apellidop.value;
	celular=document.nuevo_usuario.celular.value;
	email=document.nuevo_usuario.email.value;
	direccion=document.nuevo_usuario.direccion.value;
	ci=document.nuevo_usuario.ci.value;
	usuario=document.nuevo_usuario.usuario.value;
	password=document.nuevo_usuario.password.value;
	estado=document.nuevo_usuario.estado.value;
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "../c/usuario.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("nombrep="+nombrep+"&apellidop="+apellidop+"&celular="+celular+"&email="+email+"&direccion="+direccion+"&ci="+ci+"&usuario="+usuario+"&password="+password+"&estado="+estado);
	//
}
function modificarusuario(){
	//donde se mostrará el formUsu con los datos
	//Form = document.getElementById('Form');
	id=document.editar_usuario.id.value;
	nombrep=document.editar_usuario.nombrep.value;
	apellidop=document.editar_usuario.apellidop.value;
	celular=document.editar_usuario.celular.value;
	email=document.editar_usuario.email.value;
	direccion=document.editar_usuario.direccion.value;
	ci=document.editar_usuario.ci.value;
	usuario=document.editar_usuario.usuario.value;
	//password=document.editar_usuario.password.value;
	estado=document.editar_usuario.estado.value;
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "../c/usuario.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id+"&nombrep="+nombrep+"&apellidop="+apellidop+"&celular="+celular+"&email="+email+"&direccion="+direccion+"&ci="+ci+"&usuario="+usuario+"&estado="+estado);
	//
}
function eliminarusuario(id){
    var txt;
    var r = confirm('Desea realmente eliminar este Usuario?');
		if (r == true) {
        ajax=objetoAjax();
		ajax.open("POST", "../c/usuario.php",true);
		//Form.innerHTML= '<div class="col-md-12"> <div class="alert alert-info"> <img src="../../gcm_chat/loader.gif"></div></div>';
		ajax.onreadystatechange=function() {
			if (ajax.readyState==4 && ajax.status == 200) {
				//mostrar resUsus en esta capa
				Form.innerHTML = ajax.responseText
				Form.style.display="block";
		       }}
		//como hacemos uso del metodo GET
		//colocamos null
		ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		ajax.send("id="+id);

    } else {
        window.location.href = 'GUsuarios.php';
    }       
}
function nuevorol(){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('Form');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "NuevoRol.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send()
}
function insertperfil(){
	//donde se mostrará el formUsu con los datos
	//Form = document.getElementById('Form');
	nombre=document.nuevo_rol.nombre.value;
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "../c/perfil.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("nombre="+nombre);
	//
}
function editarperdil(id){
	//donde se mostrará el formUsu con los datos
	//Form = document.getElementById('Form');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "EditarRol.php");
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
	        Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id);
}
function modificarperfil(){
	//donde se mostrará el formUsu con los datos
	//Form = document.getElementById('Form');
	id=document.editperfil.id.value;
	nombre=document.editperfil.nombre.value;
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "../c/perfil.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id+"&nombre="+nombre);
	//
}
function gestionarperfil(){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('Form');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "GPerfil.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send()
}
function nuevoacceso(){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('FormA');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "NuevoAcceso.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send()
}
function insertacceso(){
	//donde se mostrará el formUsu con los datos
	//Form = document.getElementById('Form');
	nombre=document.nuevoacc.nombre.value;
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "../c/accesos.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("nombre="+nombre);
	//
}
function editaracceso(id){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('FormA');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "Editaracceso.php");
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
	        Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id);
}
function modificaracceso(){
	//donde se mostrará el formUsu con los datos
	//Form = document.getElementById('Form');
	id=document.editperfil.id.value;
	nombre=document.editperfil.nombre.value;
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "../c/accesos.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id+"&nombre="+nombre);
	//
}
function nuevoperfilacceso(id){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('Form');
	//	perfil=document.perfiacc.perfil.value;
	//check_list=document.perfiacc.check_list.value;
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "NuevoPerfilacceso.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id);
	//
}
function insertperfilacceso(){
    perfil=document.perfiacc.id.value;
    var check_list = document.getElementsByClassName('cb');

    //var check_list = document.getElementsByTagName('check_list[]');
        //alert(checkBoxes.length);
               var param = "";
                for (var counter=0; counter < check_list.length; counter++) {
                                if (check_list[counter].type.toUpperCase()=='CHECKBOX' && check_list[counter].checked == true) {
                                                param += check_list[counter].value +"," ;
                                }
                }
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "../c/perfilacceso.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("perfil="+perfil+"&check_list="+param);
	//
}
function gestionaracceso(){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('FormA');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "Gacceso.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send()
}
function gestionaraccesopermiso(id){
	
	Form = document.getElementById('Form');
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "accesopermiso.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id);
}
function permisoacceso(){
    id=document.getElementById("id").value;
	var rec = document.getElementsByClassName('rec');
               var prec = "";
                for (var counter=0; counter < rec.length; counter++) {
                                if (rec[counter].type.toUpperCase()=='CHECKBOX' && rec[counter].checked == true) {
                                                prec += rec[counter].value +"," ;
                				}
				}
    var c = document.getElementsByClassName('c');
               var pc = "";
                for (var counter=0; counter < c.length; counter++) {
                                if (c[counter].type.toUpperCase()=='CHECKBOX' && c[counter].checked == true) {
                                                pc += 1 +"," ;
                                }else{
                                	           pc += 0 +"," ;
                                }
                }
	var r = document.getElementsByClassName('r');
               var pr = "";
                for (var counter=0; counter < r.length; counter++) {
                                if (r[counter].type.toUpperCase()=='CHECKBOX' && r[counter].checked == true) {
                                                pr += 1 +"," ;
                                }else{
                                	           pr += 0 +"," ;
                                }
                }
    var u = document.getElementsByClassName('u');
               var pu= "";
                for (var counter=0; counter < u.length; counter++) {
                                if (u[counter].type.toUpperCase()=='CHECKBOX' && u[counter].checked == true) {
                                                pu += 1 +"," ;
                                }else{
                                	           pu += 0 +"," ;
                                }
                }
    var d = document.getElementsByClassName('d');
               var pd = "";
                for (var counter=0; counter < d.length; counter++) {
                                if (d[counter].type.toUpperCase()=='CHECKBOX' && d[counter].checked == true) {
                                                pd += 1 +"," ;
                                }else{
                                	           pd += 0 +"," ;
                                }
                }                
                //alert(id+"\n"+prec+"\n"+pc+"\n"+pr+"\n"+pu+"\n"+pd);
    var pur = document.getElementsByClassName('pu');
               var pus = "";
                for (var counter=0; counter < pur.length; counter++) {
                                if (pur[counter].type.toUpperCase()=='CHECKBOX' && pur[counter].checked == true) {
                                                pus += 1 +"," ;
                                }else{
                                	           pus += 0 +"," ;
                                }
                }
    var cn = document.getElementsByClassName('cn');
               var cnh = "";
                for (var counter=0; counter < cn.length; counter++) {
                                if (cn[counter].type.toUpperCase()=='CHECKBOX' && cn[counter].checked == true) {
                                                cnh += 1 +"," ;
                                }else{
                                	           cnh += 0 +"," ;
                                }
                }
    var a = document.getElementsByClassName('a');
               var acc = "";
                for (var counter=0; counter < a.length; counter++) {
                                if (a[counter].type.toUpperCase()=='CHECKBOX' && a[counter].checked == true) {
                                                acc += 1 +"," ;
                                }else{
                                	           acc += 0 +"," ;
                                }
                }
    var prll = document.getElementsByClassName('pr');
               var prl = "";
                for (var counter=0; counter < prll.length; counter++) {
                                if (prll[counter].type.toUpperCase()=='CHECKBOX' && prll[counter].checked == true) {
                                                prl += 1 +"," ;
                                }else{
                                	           prl += 0 +"," ;
                                }
                }
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "../c/PermisosAcceso.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id+"&prec="+prec+"&c="+pc+"&r="+pr+"&u="+pu+"&d="+pd+"&pu="+pus+"&cn="+cnh+"&a="+acc+"&pr="+prl);
  //ajax.send("id="id+"&prec="+prec+"&c="+pc+"&r="+pr+"&u="+pu+"&d="+pd);
	//
}
function insertpermisousuario(){

    id=document.nuevo_permiso.id.value;
    perm=document.nuevo_permiso.perm.value;
    env=document.getElementById("enviar").value;
    ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "../c/PermisoUsuario.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id+"&perm="+perm+"&env="+env);
	//
}
function verpermisousuario(uid){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('Form');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "permisousuario.php");
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
	        Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+uid)
}
function VerPerfilUsuario(id){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('page-wrapper');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "vistaPerfilUsuario.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id)
}
function PerfilUsuarioforma(id){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('page-wrapper');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "vistaPerfilUsuario.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id)
}
function resetpassusuario(id,pass){
    var txt;
    var r = confirm('Desea realmente resetear la contraseña del Usuario?');
		if (r == true) {
        ajax=objetoAjax();
		ajax.open("POST", "../c/usuario.php",true);
		ajax.onreadystatechange=function() {
			if (ajax.readyState==4 && ajax.status == 200) {
				//mostrar resUsus en esta capa
				Form.innerHTML = ajax.responseText
				Form.style.display="block";
		       }}
		//como hacemos uso del metodo GET
		//colocamos null
		ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		ajax.send("id="+id+"&usuario="+pass);

    } else {
        window.location.href = 'GUsuarios.php';
    }       
}

// ------------- CAMPAMENTO ----------------------
function nuevocampamento(){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('Form');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "NuevoCampamento.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send()
}
function insertcampamento(){
	
    nombre=document.nuevo_campamento.nombre.value;
    tipo=document.nuevo_campamento.tipo.value;
    lugar=document.nuevo_campamento.lugar.value;
    descripcion=document.nuevo_campamento.descripcion.value;
    fi=document.nuevo_campamento.fi.value;
    ff=document.nuevo_campamento.ff.value;
    monto=document.nuevo_campamento.monto.value;
    descuento=document.nuevo_campamento.descuento.value;
    cantidad=document.nuevo_campamento.cantidad.value;
    cmaxpersona=document.nuevo_campamento.cmaxpersona.value;
    estado=document.nuevo_campamento.estado.value;   
    imagen=document.nuevo_campamento.imagen.value;   

	//imagen=document.getElementById("imagen").files;

	    ajax=objetoAjax();
  
	//uso del medotod POST
	ajax.open("POST", "../c/campamento.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("nombre="+nombre+"&tipo="+tipo+"&lugar="+lugar+"&descripcion="+descripcion+"&fi="+fi+"&ff="+ff+"&monto="+monto+"&descuento="+descuento+"&cantidad="+cantidad+"&cmaxpersona="+cmaxpersona+"&estado="+estado+"&imagen="+imagen);
	
	//
}
function editarcampamento(id){
	
	Form = document.getElementById('Form');
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "EditarCampamento.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id);
}
function actualizarcampamento(){
	id=document.nuevo_campamento.id.value;
	costoid=document.nuevo_campamento.costoid.value;
    nombre=document.nuevo_campamento.nombre.value;
    tipo=document.nuevo_campamento.tipo.value;
    lugar=document.nuevo_campamento.lugar.value;
    descripcion=document.nuevo_campamento.descripcion.value;
    fi=document.nuevo_campamento.fi.value;
    ff=document.nuevo_campamento.ff.value;
    monto=document.nuevo_campamento.monto.value;
    descuento=document.nuevo_campamento.descuento.value;
    cantidad=document.nuevo_campamento.cantidad.value;
    cmaxpersona=document.nuevo_campamento.cmaxpersona.value;
    imagen=document.nuevo_campamento.imagen.value;
    estado=document.nuevo_campamento.estado.value;
   
    ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "../c/campamento.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id+"&costoid="+costoid+"&nombre="+nombre+"&tipo="+tipo+"&lugar="+lugar+"&descripcion="+descripcion+"&fi="+fi+"&ff="+ff+"&monto="+monto+"&descuento="+descuento+"&cantidad="+cantidad+"&cmaxpersona="+cmaxpersona+"&imagen="+imagen+"&estado="+estado);
	//
}
function eliminarcampamento(id){
    var txt;
    var r = confirm('Desea realmente eliminar este Campamento?');
		if (r == true) {
        ajax=objetoAjax();
		ajax.open("POST", "../c/campamento.php",true);
		//Form.innerHTML= '<div class="col-md-12"> <div class="alert alert-info"> <img src="../../gcm_chat/loader.gif"></div></div>';
		ajax.onreadystatechange=function() {
			if (ajax.readyState==4 && ajax.status == 200) {
				//mostrar resUsus en esta capa
				Form.innerHTML = ajax.responseText
				Form.style.display="block";
		       }}
		//como hacemos uso del metodo GET
		//colocamos null
		ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		ajax.send("id="+id);

    } else {
        window.location.href = 'Gcampamento.php';
    }       
}

function detallecampamento(id){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('Form');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "detallecampamento.php");
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
	        Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id)
}
//----------------- PARTICIPANTE---------------

function insertarparticipante(){
	//donde se mostrará el formUsu con los datos
	//Form = document.getElementById('Form');
	nombre=document.participante.nombre.value;
	apellido=document.participante.apellido.value;
	telefono=document.participante.telefono.value;
	celular=document.participante.celular.value;
	email=document.participante.email.value;
	direccion=document.participante.direccion.value;
	ci=document.participante.ci.value;
	iglesia=document.participante.iglesia.value;
	usuario=document.participante.usuario.value;
	password=document.participante.password.value;
	//instanciamos el objetoAjax
	
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "../c/participantes.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("nombre="+nombre+"&apellido="+apellido+"&telefono="+telefono+"&celular="+celular+"&email="+email+"&direccion="+direccion+"&ci="+ci+"&iglesia="+iglesia+"&usuario="+usuario+"&password="+password);
	//
}
function editaruparticipante(id){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('Form');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "EditarUsuario.php");
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
	        Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id)
}
function modificarparticipante(){
	//donde se mostrará el formUsu con los datos
	//Form = document.getElementById('Form');
	id=document.nuevo_participante.id.value;
	nombre=document.nuevo_participante.nombrep.value;
	apellido=document.nuevo_participante.apellido.value;
	telefono=document.nuevo_participante.telefono.value;
	celular=document.nuevo_participante.celular.value;
	email=document.nuevo_participante.email.value;
	direccion=document.nuevo_participante.direccion.value;
	ci=document.nuevo_participante.ci.value;
	iglesia=document.nuevo_participante.iglesia.value;
	usuario=document.nuevo_participante.usuario.value;
	password=document.nuevo_participante.password.value;
	estado=document.nuevo_participante.estado.value;
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "../c/participantes.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
			Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id+"nombre="+nombre+"&apellido="+apellido+"&telefono="+telefono+"&celular="+celular+"&email="+email+"&direccion="+direccion+"&ci="+ci+"&iglesia="+iglesia+"&usuario="+usuario+"&password="+password+"&estado="+estado);
	//
}
function eliminarparticipante(id){
    var txt;
    var r = confirm('Desea realmente eliminar este Usuario?');
		if (r == true) {
        ajax=objetoAjax();
		ajax.open("POST", "../c/participantes.php",true);
		//Form.innerHTML= '<div class="col-md-12"> <div class="alert alert-info"> <img src="../../gcm_chat/loader.gif"></div></div>';
		ajax.onreadystatechange=function() {
			if (ajax.readyState==4 && ajax.status == 200) {
				//mostrar resUsus en esta capa
				Form.innerHTML = ajax.responseText
				Form.style.display="block";
		       }}
		//como hacemos uso del metodo GET
		//colocamos null
		ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		ajax.send("id="+id);

    } else {
        window.location.href = 'GUsuarios.php';
    }       
}

//------------------------ inscipcion------------
function confpagoinscripcion(){
	//donde se mostrará el formUsu con los datos
	
	idp=document.confinscripcion.idp.value;
	idc=document.confinscripcion.idc.value;
	fi=document.confinscripcion.fi.value;
	fp=document.confinscripcion.fp.value;
	monto=document.confinscripcion.monto.value;
	
	
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "../c/registros.php");
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText;
	        Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("idp="+idp+"&idc="+idc+"&fi="+fi+"&fp="+fp+"&monto="+monto)
}
function listainscpago(id){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('Form');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "detalleinscritospago.php");
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
	        Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id)
}

function realizapago(id){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('Form');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "realizarpago.php");
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
	        Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id)
}
function grealizapago(id){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('Form');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "Grealizapago.php");
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText
	        Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id)
}


function pagorealizado(){
	//donde se mostrará el formUsu con los datos

	idp=document.pago.idp.value;
	monto=document.pago.monto.value;

	imagen=document.pago.imagen.value;
	

	
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "../c/pago.php");
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa
			Form.innerHTML = ajax.responseText;
	        Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("idp="+idp+"&monto="+monto+"&imagen="+imagen)
}

function detallecampamentoini(id){
	//donde se mostrará el formUsu con los datos
	Form = document.getElementById('Form');
	//instanciamos el objetoAjax
	ajax=objetoAjax();
	//uso del medotod POST
	ajax.open("POST", "v/detallecampamentoini.php");
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4 && ajax.status == 200) {
			//mostrar resUsus en esta capa/
			Form.innerHTML = ajax.responseText
	        Form.style.display="block";
		}
	}
	//como hacemos uso del metodo POST
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//enviando el codigo del empleado
	ajax.send("id="+id)
}