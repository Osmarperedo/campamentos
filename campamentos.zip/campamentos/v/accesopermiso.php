<?php
require_once '../m/db_functions.php';
$idp=$_POST['id'];
 $demo = new DB_Functions();
  
?>      

                        <div class="form-group">
                           <label for="exampleInputEmail1" >Perfil </label>
                              <?php
                                $perfil = $demo->listRolid($idp);
                                foreach ($perfil as $key => $perfi) {
                              ?>
                                <input class="form-control" id="id" name="id" type="hidden" value="<?= $perfi['id'] ?>"/>
                                <input class="form-control" type="text" value="<?= $perfi['nombre'] ?>" disabled/>
                              <?php }?>
                                                                                               
                        </div>
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           PERFIL - ACCESO -PERMISO
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Nombre</th>                                        
                                            <th>Consultar</th>
                                            <th>Insertar</th>
                                            <th>Modificar</th>
                                            <th>Eliminar</th>
                                            <th>Persmiso </br>Usuario</th>
                                            <th>contrasena</th>
                                            <th>acceso</th>
                                            <th>Permiso</br>Rol</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                            <?php
                                                //$demo = new Smsencrip();
                                                $users = $demo->listaccesocheckid($idp);
                                                $i=1;
                                                foreach ($users as $key => $user) {
                                            ?>
                                          <tr>
                                            <td><?= $i;?></td>
                                            <td><input class="rec" id="id" name="id" type="checkbox" value="<?= $user['id'] ?>" checked disabled style="display:none;"/><?= $user['nombre'] ?></td>

                                            <td><input class="c" type="checkbox" name="check_r" value="<?= $user['consulta'] ?>" <?= $user['consulta'] ?> /></td>

                                            <?php if($user['id']===6) {?>

                                            <td><input class="r" type="checkbox" name="check_r" value="<?= $user['agregar'] ?>" <?= $user['agregar'] ?> disabled style="display:none;"/></td>
                                            <?php }else{?>
                                            <td><input class="r" type="checkbox" name="check_r" value="<?= $user['agregar'] ?>" <?= $user['agregar'] ?> /></td>
                                            <?php }if($user['id']===6) {?>

                                            <td><input class="u" type="checkbox" name="check_u" value="<?= $user['editar'] ?>" <?= $user['editar'] ?> disabled style="display:none;"/></td>
                                            <?php }else{?>
                                            <td><input class="u" type="checkbox" name="check_u" value="<?= $user['editar'] ?>" <?= $user['editar'] ?> /></td>

                                            <?php }if($user['id']===1 || $user['id']===8 || $user['id']===6) {?>
                                            <td><input class="d" type="checkbox" name="check_d" value="<?= $user['eliminar'] ?>" <?= $user['eliminar'] ?> disabled style="display:none;"/></td>
                                            <?php }else{?>
                                            <td><input class="d" type="checkbox" name="check_d" value="<?= $user['eliminar'] ?>" <?= $user['eliminar'] ?> /></td>
                                            <?php } ?>
                                            <?php if($user['id']===2) {?>
                                            <td><input class="pu" type="checkbox" name="check_d" value="<?= $user['persmisousu'] ?>" <?= $user['persmisousu'] ?> /></td>
                                            <?php }else{?>
                                            <td><input class="pu" type="checkbox" name="check_d" value="<?= $user['persmisousu'] ?>" <?= $user['persmisousu'] ?> disabled style="display:none;"/></td>
                                            <?php } ?>
                                            <?php if($user['id']===2) {?>
                                            <td><input class="cn" type="checkbox" name="check_d" value="<?= $user['contrasena'] ?>" <?= $user['contrasena'] ?> /></td>
                                            <?php }else{?>
                                            <td><input class="cn" type="checkbox" name="check_d" value="<?= $user['contrasena'] ?>" <?= $user['contrasena'] ?> disabled style="display:none;"/></td>
                                            <?php } ?>
                                            <?php if($user['id']===1) {?>
                                            <td><input class="a" type="checkbox" name="check_d" value="<?= $user['acceso'] ?>" <?= $user['acceso'] ?> /></td>
                                            <?php }else{?>
                                            <td><input class="a" type="checkbox" name="check_d" value="<?= $user['acceso'] ?>" <?= $user['acceso'] ?> disabled style="display:none;"/></td>

                                            <?php } ?>
                                            <?php if($user['id']===1) {?>
                                            <td><input class="pr" type="checkbox" name="check_d" value="<?= $user['permisorol'] ?>" <?= $user['permisorol'] ?> /></td>
                                            <?php }else{?>
                                            <td><input class="pr" type="checkbox" name="check_d" value="<?= $user['permisorol'] ?>" <?= $user['permisorol'] ?> disabled style="display:none;"/></td>
                                            <?php } ?>

                                          </tr>
                                            <?php
                                                $i++;
                                                }
                                            ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>

                    </div>        
    
                    <button type="submit" name="submit" onClick="permisoacceso()" class="btn btn-default">Guardar</button>