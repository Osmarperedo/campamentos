<?php
require_once '../m/db_functions.php';
$idp=$_POST['id'];
 $demo = new DB_Functions();
  //if (isset($_GET['id']){
  //$var=$_GET['id'];
  //} 
?>      

        <div class="panel-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           PERFIL - ACCESO
                        </div>
                        <div class="panel-body">
         
                           <form name="perfiacc" method="POST" onSubmit="insertperfilacceso(); return false">
                                <div class="form-group">
                                    <label for="exampleInputEmail1" >Nombre </label>
                                        <!--select class="form-control" name="perfil" id="perfil" onChange="run()"-->
                                        <?php
                                            $perfil = $demo->listRolid($idp);
                                              foreach ($perfil as $key => $perfi) {
                                            ?>
                                                   <input class="form-control" id="id" name="id" type="hidden" value="<?= $perfi['id'] ?>"/>
                                                   <input class="form-control" type="text" value="<?= $perfi['nombre'] ?>" disabled/>
                                              <?php }?>
                                                                       
                                </div>
                                <div class="form-group">
                                            <label>Accesos Actuales</label>
                                                                       <div class="checkbox">
                                                                        <?php
                                                                        /*$regiaos2 = '<p id="r" name="r" ></p>';
                                                                        echo $regiaos2; 

                                                                        if (isset($_POST['r'])){
                                                                          $a=$_POST['r'];
                                                                          echo $a;
                                                                        }*/
                                                                        
                                                                        $rols = $demo->listRolcheckid($idp);
                                                                       // $regiaos = '<input type="text" id="rstregiao" name="rstregiao" placeholder="valor">';
                                                                       // echo $regiaos; 
                                                                        //$rols = $demo->listRolcheckid(2);
                                                                           foreach ($rols as $key => $rol) {
                                                                         ?>
                                                                            <label>
                                                                                <input type="checkbox" value="<?= $rol['id'] ?>" checked="<?= $rol['checked'] ?> " disabled/> <?= $rol['nombre'] ?> 
                                                                          </label>              
                                                                       <?php } ?>
                                                                      
                                             </div>
                                             </div>
                                             <div class="form-group">
                                            <label>Accesos Nuevos</label>
                                

                                             <div class="checkbox" >
                                                                        <?php
                                                                        $rols = $demo->listRolnocheckid($idp);
                                                                           foreach ($rols as $key => $rolno) {
                                                                         ?>
                                                                            <label>
                                                                                <input class="cb" type="checkbox" name="check_list[]" value="<?= $rolno['id'] ?>" /> <?= $rolno['nombre'] ?> 
                                                                          </label>              
                                                                       <?php } ?>
                                                                      
                                             </div>
                                             </div>
                                            <button type="submit" class="btn btn-primary">Guardar </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>