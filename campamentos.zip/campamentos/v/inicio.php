<?php
require_once '../m/db_functions.php';
    session_start();
    if(isset ($_SESSION['id'])) {
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Bootstrap Admin Template : Binary Admin</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="inicio.php">Inicio</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> <a href="../index.php" class="btn btn-danger square-btn-adjust">Logout</a>   </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
					</li>                   
					          <li>
                        <a  href="#"> <strong>  
                        <?php 
                        echo $_SESSION['name'] ; 
                        echo " " ;  
                        echo $_SESSION['apellido']; 
                        ?> </strong></a>
                    </li>
                    <?php
                    $demo = new DB_Functions();
                    $rols = $demo->listpermisos($_SESSION['id']);

                    foreach ($rols as $key => $perm) {
                    if ($perm['recurso_id']===1){
                    ?>
                    <li>
                        <a class="active-menu"  href="Grol.php"><i class="fa fa-dashboard "></i> Gestion Roles</a>
                    </li>
                    <?php } if($perm['recurso_id']===2) {?>
                     <li>
                        <a  href="Gusuario.php"><i class="fa fa-desktop "></i> Gestión Usuarios</a>
                    </li>
                    <?php } if($perm['recurso_id']===3) {?>
                    <li>
                        <a  href="Gcampamento.php"><i class="fa fa-qrcode "></i> Gestion Campamentos</a>
                    </li>
                    <?php } if($perm['recurso_id']===4) {?>
                    <li  >
                        <a   href="Gregistros.php"><i class="fa fa-bar-chart-o "></i> Gestión Registros</a>
                    </li>   
                    <?php } if($perm['recurso_id']===5) {?>
                    <li  >
                        <a  href="Gpagos.php"><i class="fa fa-table "></i> Gestion Pagos</a>
                    </li>
                    <?php } if($perm['recurso_id']===6) {?>
                    <li  >
                        <a  href="Greportes.php"><i class="fa fa-edit "></i> Reportes </a>                  
                    </li>
                     <?php 
                     }   }
                     ?>
                </ul>               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner" >
                <div class="row">
                    <div class="col-md-12" >
                     <h2>Campamentos</h2>   
                        <h5>Bienvendio a nuestro espacio</h5>
                        <br/>
                    </div>
                </div>              
                 <!-- /. ROW  -->
                <div class="row">
                    <div class="col-md-12" id="Form">
                         <?php
                         
                                                $users = $demo->ListCampametnos();
                                                $i=1;
                                                foreach ($users as $key => $user) {
                        ?>
                        <?php  //for($i=0; $i < 10;$i++) { ?>
                         <div class="col-xs-6 col-md-3">
                            <div class="thumbnail">
                              <img src="assets/img/batman.jpg" alt="...">
                              <div class="caption">
                                <h3><?= $user['nombre'] ?></h3>
                                <h5><strong><?= $user['tipo_campamento'] ?></strong></h5>
                                <!--h5><?= $user['descripcion'] ?></h5-->
                                <h5><strong>De Fecha :</strong> <?= $user['fecha_inicio'] ?> <strong>hasta :</strong> <?= $user['fecha_final'] ?></h5>
                                <h5><strong> Precio : </strong><?= $user['monto'] ?></h5>
                                <h5><strong>Descuento :</strong><?= $user['descuento']?> <strong>% a las </strong><?= $user['cantidad'] ?> <strong>primeros</strong></h5>
                                <h5><strong>Cupo: </strong> <?= $user['cupo_max'] ?> personas</h5>
                                <p> <button class="btn btn-success" type="button" onClick="detallecampamento(<?= $user['campamento_id'] ?>)">Detalle</button></p>
                                <!--a href="../v/detallecampamento.php" class="btn btn-default" role="button">Detalle</a-->
                              </div>
                            </div>
                        </div>
                        <?php } ?>
                        

                    </div>
                </div>
                 <!-- /. END ROW  -->           
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
       <script type="text/javascript" src="assets/js/ajax.js"></script>
    <script type="text/javascript" src="assets/js/validator.js"></script>
    
   
</body>
</html>
<?php
}else{
//header("Location: ../index.php"); 
header("Location: ../vista/error403.html"); } ?>
