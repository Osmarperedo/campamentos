<?php
require_once '../m/db_functions.php';
$id=$_POST['id'];
 $demo = new DB_Functions();
  $users = $demo->listCampametnosid($id);
  foreach ($users as $key => $user) {

?>                  
                  <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                          <div class="panel-heading">
                              EDITAR CAMPAMENTO
                          </div>
                        <div class="panel-body">
                           <form  role="form" id="nuevo_campamento" name="nuevo_campamento" method="POST" action="" onSubmit="actualizarcampamento(); return false" >
                              <div class="form-group">
                                <label for="nombre" class="control-label">Nombre *</label>
                                <input type="hidden" class="form-control" name="id" id="id" value="<?= $user['campamento_id'] ?>"/>
                                <input type="hidden" class="form-control" name="costoid" id="costoid" value="<?= $user['idcosto'] ?>"/>
                                <input style="text-transform:capitalize;" type="text" class="form-control" name="nombre" id="nombre" placeholder="Enter nombre" onkeypress="return soloLetras(event)" value="<?= $user['nombre'] ?>" required/>
                              </div>
                              <div class="form-group">
                                <label for="tipo">Tipo *</label>
                                <input style="text-transform:capitalize;" type="text" class="form-control" name="tipo"id="tipo" placeholder="Enter apellido" onkeypress="return isAlphanumeric(event)" value="<?= $user['tipo_campamento'] ?>" required/>                            
                              </div>
                              <div class="form-group">
                                <label for="lugar">Lugar *</label>
                                <input style="text-transform:capitalize;" type="text" class="form-control" name="lugar"id="lugar" placeholder="Enter apellido" onkeypress="return isAlphanumeric(event)" value="<?= $user['lugar'] ?>" required/>                            
                              </div>
                              <div class="form-group">
                                <label for="descripcion">Descripcion *</label>
                                <textarea style="text-transform:capitalize;" class="form-control" rows="3" name="descripcion" id="descripcion"placeholder="Enter Descripción" onkeypress="return isAlphanumeric(event)" required><?= $user['descripcion'] ?></textarea>
                                                            
                              </div>
                              <div class="form-group">
                                <label for="fi">Fecha inicio *</label>
                                <input class="form-control" type="date" id="fi" name="fi"  value="<?= $user['fecha_inicio'] ?>"required>
                              </div>
                              <div class="form-group">
                                <label for="ff">Fecha Final *</label>
                                <input class="form-control" type="date" id="ff" name="ff" value="<?= $user['fecha_final'] ?>" required>
                              </div>
                              <div class="form-group">
                              <label for="monto">Monto *</label>
                              <div class="form-group input-group">
                                <span class="input-group-addon">Bs.</span>
                                <input type="text" class="form-control" name="monto" id="monto" value="<?= $user['monto'] ?>" onkeypress="return isNumberKey(event)" required/>
                                <span class="input-group-addon">.00</span>
                              </div>
                              </div>
                              <div class="form-group">
                                <label for="descuento">Descuento *</label>
                                <div class="form-group input-group">                              
                                <input type="text" class="form-control" name="descuento" id="descuento" placeholder="Enter descuento" value="<?= $user['descuento'] ?>" onkeypress="return isNumberKey(event)" required/>
                                <span class="input-group-addon">%</span>
                                </div>
                              </div>
                              <div class="form-group">
                                    <label for="cantidad">Cantidad de inscritos con descuento*</label>
                                    
                                    <input type="text" class="form-control" name ="cantidad" id="cantidad" placeholder="Enter cantidad" value="<?= $user['cantidad'] ?>" onkeypress="return isNumberKey(event)" required/>                                
                                    
                                    
                              </div>
                              <div class="form-group">
                                    <label for="cmaxpersona">Cantidad Max de Personas *</label>
                                    <input type="text" class="form-control" name ="cmaxpersona" id="cmaxpersona" placeholder="Enter Cantidad max personas" value="<?= $user['cupo_max'] ?>" onkeypress="return isNumberKey(event)" required/>                                
                              </div>
                              <div class="form-group">
                                    <label for="imagen">Imagen *</label>
                                    <input type="file" name="imagen" id="imagen" value="<?= $user['imagen'] ?>" required />                                
                              </div>

                              
                              <div class="form-group">
                                                <label>Estado *</label>
                                                <select class="form-control" name="estado" required>
                                                    <option value="">Elija una opcion</option>
                                                    <option value="0">Activo</option>
                                                    <option value="1">Suspenso</option>
                                                </select>
                              </div>
                                 <button type="submit" class="btn btn-primary" >Guardar</button>
                            </form>
                        </div>
                        </div>
                    </div>
                   </div>
<?php
}
?>