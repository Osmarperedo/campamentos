<?php
require_once '../m/db_functions.php';
$id=$_POST['usuario_id'];
 $demo = new DB_Functions();
  $users = $demo->listUsuariosid($id);
 

?>
                  <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                            EDITAR PERSONA
                        </div>
                        <div class="panel-body">
                       <form name="editar_usuario" method="POST" action="" onSubmit="modificarusuario(); return false">
                        <?php foreach ($users as $key => $user) { ?>
                          <div class="form-group">
                            <label for="nombrep">Nombre :</label>
                            <input type="hidden" id="id" name="id" value="<?= $user['usuario_id'] ?>" />
                            <input style="text-transform:capitalize;" type="text" class="form-control" id="nombrep" name="nombrep" placeholder="Enter nombre" value="<?= $user['nombre_u'] ?>" onkeypress="return soloLetras(event)" required/>
                          </div>
                          <div class="form-group">
                            <label for="apellidop">Apellido</label>
                            <input style="text-transform:capitalize;" type="text" class="form-control" id="apellidop" name="apellidop" placeholder="Enter apellido" value="<?= $user['apellido'] ?>" onkeypress="return soloLetras(event)" required/>
                          </div>
                          <div class="form-group">
                            <label for="celular">Celular</label>
                            <input maxlength="8" type="tel" class="form-control" id="celular" name ="celular" placeholder="Enter celular" value="<?= $user['celular'] ?>" onkeypress="return isNumberKey(event)" required/>
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" value="<?= $user['email'] ?>"/>
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">Dirección</label>
                            <input type="text" class="form-control" id="direccion" name="direccion" placeholder="Enter dirección" value="<?= $user['direccion'] ?>" onkeypress="return isAlphanumeric(event)" />
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">C.I.</label>
                            <input maxlength="8" type="text" class="form-control" id="ci" name="ci" placeholder="Enter C.I." value="<?= $user['ci'] ?>" onkeypress="return isNumberKey(event)" required/>
                          </div>
                          <div class="panel panel-default">
                          <div class="panel-heading">
                           EDITAR USUARIO
                        </div>
                        </div>
                          <div class="form-group">
                                <label for="exampleInputEmail1">Usuario</label>
                                <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Enter usuario" value="<?= $user['nombre_u'] ?>" onkeypress="return isAlphanumeric(event)" required/>
                              </div>                             
                              <div class="form-group">
                                  <label>Estado </label>
                                    <select class="form-control" name="estado" required>
                                      <option value="">Elija una opcion</option>
                                      <option value="0">Activo</option>
                                      <option value="1">Suspenso</option>
                                    </select>
                              </div>
                              <hr />
                             <button type="submit" class="btn btn-primary" >Enviar</button>
                             <?php
                                }
                              ?>
                            </form>
                            </div>
                            </div>
                    </div>
                    
                </div>
