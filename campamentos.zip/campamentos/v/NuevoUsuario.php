                  <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                          <div class="panel-heading">
                              NUEVA PERSONA
                          </div>
                        <div class="panel-body">
                           <form id="nuevo_usuario" name="nuevo_usuario" method="POST" action="" onSubmit="insertarusuario(); return false" >
                              <div class="form-group">
                                <label for="nombrep" class="control-label">Nombre *</label>
                                <input style="text-transform:capitalize;" type="text" class="form-control" name="nombrep" id="nombrep" placeholder="Enter nombre" onkeypress="return soloLetras(event)" required/>
                              </div>
                              <div class="form-group">
                                <label for="apellidop">Apellido *</label>
                                <input style="text-transform:capitalize;" type="text" class="form-control" name="apellidop"id="apellidop" placeholder="Enter apellido" onkeypress="return soloLetras(event)" required/>                            
                              </div>
                              <div class="form-group">
                                <label for="exampleInputemail1">Celular *</label>
                                <input maxlength="8" type="text" class="form-control" name="celular" id="celular" placeholder="Enter celular" onkeypress="return isNumberKey(event)" required/>
                              </div>
                              <div class="form-group">
                                <label for="email">Email *</label>
                                <input type="email" class="form-control" name="email" id="email" placeholder="Enter text" required />
                              </div>
                              <div class="form-group">
                                <label for="direccion">Dirección</label>
                                <input type="text" class="form-control" name="direccion" id="direccion" placeholder="Enter dirección" onkeypress="return isAlphanumeric(event)" />
                              </div>
                              <div class="form-group">
                                <label for="ci">C.I. *</label>
                                <input maxlength="8" type="tel" class="form-control" name ="ci" id="ci" placeholder="Enter C.I." onkeypress="return isNumberKey(event)" required/>
                              </div>
                              <div class="form-group">
                                    <label for="usuario">Usuario *</label>
                                    <input type="text" class="form-control" name ="usuario" id="usuario" placeholder="Enter usuario"  onkeypress="return soloLetras(event)" required/>                                
                              </div>
                              <div class="form-group">
                                    <label for="password">Contraseña *</label>
                                    <input type="password" class="form-control" name ="password" id="password" placeholder="Enter contraseña" onkeypress="return isAlphanumeric(event)" required/>
                              </div>
                                  <!--div class="form-group">
                                    <label for="exampleInputemail1">Confirmar contraseña</label>
                                    <input type="text" class="form-control" id="cpassword" placeholder="Enter contraseña" />
                                  </div-->
                                  <div class="form-group">
                                                <label>Estado *</label>
                                                <select class="form-control" name="estado" required>
                                                    <option value="">Elija una opcion</option>
                                                    <option value="0">Activo</option>
                                                    <option value="1">Suspenso</option>
                                                </select>
                                  </div>
                              <hr />
                                 <button type="submit" class="btn btn-primary" >Guardar</button>

                            </form>
                        </div>
                        </div>
                    </div>
                   </div>

   