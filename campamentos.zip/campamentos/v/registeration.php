﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Bootstrap Admin Template : Binary Admin</title>
  <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../index.php">Inicio</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">  </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
        <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
          </li>                   
                    <li  >
                        <a   href="login.php"><i class="fa fa-bolt "></i> Login</a>
                    </li> 
                    <li  >
                        <a   href="registeration.php"><i class="fa fa-laptop "></i> Registrarse</a>
                    </li>                    
                </ul>               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner" >
                    
                 <!-- /. ROW  -->
                <div class="row">
                    <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1" id="Form" >
                    <div class="row text-center  ">
              <div class="col-md-12">
                  <br /><br />
                  <h2> Nuevo Registro</h2>
                 
                  <h5>( Registrarse ahora para acceso al sistemas)</h5>
                   <br />
              </div>
        
            </div>    
                        <div class="panel panel-default">
                            <div class="panel-heading">
                        <strong>  ¿ Nuevo Usuario ? Registrarse ahora </strong>  
                            </div>
                            <div class="panel-body">
                                <form id="participante" name="participante" method="POST" action="" onSubmit="insertarparticipante(); return false" >
                                                <br/>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="fa fa-circle-o-notch"  ></i></span>
                                            <input type="text" class="form-control" placeholder="Nombre" style="text-transform:capitalize;" name="nombre" id="nombre"onkeypress="return soloLetras(event)" required/>
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="fa fa-tag"  ></i></span>
                                            <input type="text" class="form-control" placeholder="Apellido" style="text-transform:capitalize;" name="apellido" id="apellido"onkeypress="return soloLetras(event)" required />
                                        </div>
                                         <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"  ></i></span>
                                            <input type="text" class="form-control" placeholder="Telefono" maxlength="8" name="telefono" id="telefono" onkeypress="return isNumberKey(event)"/>
                                        </div>
                                         <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-phone"  ></i></span>
                                            <input type="text" class="form-control" placeholder="Celular" maxlength="8" name="celular" id="celular" onkeypress="return isNumberKey(event)" required/>
                                        </div>
                                         <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"  ></i></span>
                                            <input type="email" class="form-control" placeholder="Email" name="email" id="email"required/>
                                        </div>
                                         <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-map-marker"  ></i></span>
                                            <input type="text" class="form-control" placeholder="Dirección" style="text-transform:capitalize;" name="direccion" id="direccion" onkeypress="return isAlphanumeric(event)"/>
                                        </div>
                                         <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-credit-card"  ></i></span>
                                            <input type="text" class="form-control" placeholder="C.I. " maxlength="8" name ="ci" id="ci" onkeypress="return isNumberKey(event)" required />
                                        </div>
                                         <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-tower"  ></i></span>
                                            <input type="text" class="form-control" placeholder="Iglesia" style="text-transform:capitalize;" name="iglesia" id="iglesia" onkeypress="return soloLetras(event)" required />
                                        </div>
                                         <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                            <input type="text" class="form-control" placeholder="Usuario" name="usuario" id="usuario" onkeypress="return soloLetras(event)" required />
                                        </div>
                                      <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="fa fa-lock"  ></i></span>
                                            <input type="password" class="form-control" placeholder="Enter Contraseña" name ="password" id="password"onkeypress="return isAlphanumeric(event)" required/>
                                        </div>
                                        <button type="submit" class="btn btn-success " >Registrarme</button>
                                    </form>

                                    <hr />
                                    Already Registered ?  <a href="login.php" >Login here</a>
                                    
                            </div>
                           
                        </div>
                    </div>
                

                    </div>
                </div>
                 <!-- /. END ROW  -->           
            </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
    <script type="text/javascript" src="assets/js/ajax.js"></script>
    <script type="text/javascript" src="assets/js/validator.js"></script>
   
</body>
</html>
