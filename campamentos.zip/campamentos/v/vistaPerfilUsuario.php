<?php
require_once '../m/db_functions.php';
$id=$_POST['id'];
 $demo = new DB_Functions();
  $users = $demo->listUsuariosid($id);
  foreach ($users as $key => $user) {

?>
                  <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                            Mi Perfil 
                        </div>
                        <div class="panel-body">
                       <form aname="editar_usuario" method="POST" action="" onSubmit="modificarusuario(); return false">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Nombre :</label>
                            <input type="hidden" id="id" name="id" value="<?= $user['usuario_id'] ?>" />
                            <input type="text" class="form-control" id="nombrep" name="nombrep" placeholder="Enter nombre" value="<?= $user['nombre_p'] ?>" disabled/>
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">Apellido</label>
                            <input type="text" class="form-control" id="apellidop" name="apellidop" placeholder="Enter apellido" value="<?= $user['apellido_p'] ?>"disabled/>
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">Celular</label>
                            <input type="text" class="form-control" id="celular" name ="celular" placeholder="Enter celular" value="<?= $user['telefono_p'] ?>" disabled/>
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" value="<?= $user['email'] ?>"disabled/>
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">Dirección</label>
                            <input type="text" class="form-control" id="direccion" name="direccion" placeholder="Enter dirección" value="<?= $user['direccion'] ?>"disabled/>
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">C.I.</label>
                            <input type="text" class="form-control" id="ci" name="ci" placeholder="Enter C.I." value="<?= $user['ci'] ?>"disabled/>
                          </div>
                          <div class="panel panel-default">
                          <div class="panel-heading">
                           EDITAR USUARIO
                        </div>
                        </div>
                          <div class="form-group">
                                <label for="exampleInputEmail1">Usuario</label>
                                <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Enter usuario" value="<?= $user['nombre_u'] ?>"disabled/>
                              </div>                             
                              <div class="form-group">
                                  <label>Estado </label>
                                  <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Enter usuario" value="<?= $user['deleted'] ?>"disabled/>
                              </div>
                              <hr />
                             <button type="button" onClick="toogle_disabled(false);do_change(); return false;" id="a"class="btn btn-primary"
                             >Acturalizar</button>
                             <button type="summit" onClick="toogle_disabled(false)" id="g" class="btn btn-primary" style='visibility:hidden'>Guardar</button>
                             <button type="button" onClick="toogle_disabled(true)" id="c" class="btn btn-danger" style='visibility:hidden'>Cancelar</button>
                            </form>
                            </div>
                            </div>
                    </div>
                    <!--div class="col-md-6">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           EDITAR USUARIO
                        </div>
                        <div class="panel-body">
                            <form role="form">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Usuario</label>
                                <input type="text" class="form-control" id="usuario" placeholder="Enter usuario" value="<?= $user['nombre_u'] ?>"/>
                              </div>                             
                              <div class="form-group">
                                  <label>Estado </label>
                                    <select class="form-control" name="estado">
                                      <option value="0">Activo</option>
                                      <option value="1">Suspenso</option>
                                    </select>
                              </div>
                           <hr />
                             <button type="submit" class="btn btn-primary" >Submit</button>
                            </form>
                        </div>
                            </div>
                        </div-->
                </div>
<?php
}
?>