<?php
require_once '../m/db_functions.php';

$id=$_POST['id'];
    
?>

                <div class="row" >
                    <?php
                         $demo = new DB_Functions();

                         $users = $demo->listCampametnosid($id);
                         
                         foreach ($users as $key => $user) {
                        ?>
                        <?php  //for($i=0; $i < 10;$i++) { ?>
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="panel panel-primary no-boder bg-color-green">
	                        <div class="thumbnail">
                              <img src="v/assets/img/batman.jpg" alt="...">
                              <div class="caption">
                                
                                <h5><strong>Fecha </strong></h5>
                                <h5><strong>de :</strong> <?= $user['fecha_inicio'] ?> </h5><h5><strong> hasta: </strong><?= $user['fecha_final'] ?></h5>
                                                               
                              </div>
                            </div>
                    	</div>
                    </div>
                    <div class="col-md-9 col-sm-12 col-xs-12">
               
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="col-md-12">
                            <h2><?= $user['nombre'] ?></h2>
                            <br/>

                            <h5><strong>Tipo de campamento</h5></strong>
		                        <?= $user['tipo_campamento'] ?>
                                <br/>
                            <h5><strong>Descripcion</strong></h5>
                                <?= $user['descripcion'] ?>
                                <br/>
                            <!--h5><strong>Precio:</strong></h5>
                                <?= $user['monto'] ?> Bs.</h5>
                                <br/-->
                            <h5><strong>Descuento: </strong></h5>
                                <?= $user['descuento']?> % <strong>a las</strong> <?= $user['cantidad'] ?> <strong>primeras personas registradas</strong>
                                <br/>
                                <h5><strong>Cantidad maxima de personas :</strong> </h5>
                                <?= $user['cupo_max'] ?> personas 
                                <br/>
                                <!--h5><strong>Precio promocional :</strong></h5>
                                <?= $user['monto'] - $user['monto'] * $user['descuento'] /100 ?> Bs.</h5>
                                <br/-->
                                <br/>

                                                  <!--   Kitchen Sink -->
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            Detalle a pagar
                                                        </div>
                                                        <div class="panel-body">
                                                            <div class="table-responsive">
                                                           
                                                                <table class="table table-striped table-bordered table-hover">
                                                                    <thead>
                                                                        <tr>
                                                                            <th>Precio</th>
                                                                            <th>Descuento</th>
                                                                            
                                                                            <th>Monto/Descuento</th>
                                                                            <th>Total pagar</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td><?= $user['monto'] ?> Bs.</td>
                                                                            <td><?= $user['descuento']?> %</td>
                                                                            <td><?= $user['monto'] * $user['descuento'] /100 ?> Bs.</td>
                                                                            <td> <?= $user['monto'] - $user['monto'] * $user['descuento'] /100 ?> Bs.  
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>


                                <p><a href="index.php" class="btn btn-primary" role="button">Volver</a></p>

                            

                        </div>
                    <?php } ?>
                    
                    </div>
                    </div>
                </div>
                 
<?php

