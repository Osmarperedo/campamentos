<?php
require_once '../m/db_functions.php';
$id=$_POST['id'];
 session_start();
?>
                
                    <div class="col-md-6">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           COMFIRMACIÓN DE PAGO A REALIZAR
                        </div>
                        <div class="panel-body">
                         <?php
                         $demo = new DB_Functions();

                         $users = $demo->realizarpagosver($id);
                         
                         foreach ($users as $key => $user) {
                        ?>
                        <form id="pago" name="pago" method="POST" action="" onSubmit="pagorealizado(); return false">
                                      <div class="form-group">
                                           <label for="nombre" class="control-label">Nombre completo</label>
                                                <p><?php echo $_SESSION['name'] ; echo " " ; 
                                                      echo $_SESSION['apellido'];?> </p>
                                                <input type="hidden" name="idp" id="idp" value="<?= $user['idpago']?>"></input>
                                              </div>
                                              <div class="form-group">
                                                <label for="fi">Fecha Inscripción : </label>
                                                <input class="form-control" name="fi" id="fi" value="<?= $user['fecha_inscripcion'] ?>" disabled> </input> 
                                              </div>
                                              <div class="form-group">
                                                <label for="ff">Fecha limite de pago : </label>
                                                <input class="form-control" name="fp" id="fp" value="<?= $user['fecha_pago'] ?>" disabled> </input> 

                                              </div>
                                              <div class="form-group">
                                                <label for="ff">Total a pagar </label>
                                                <input class="form-control" name="monto" id="monto" value="<?= $user['monto'] ?>" disabled> </input> 

                                              </div>
                                              <div class="form-group">
                                                    <label for="imagen">Imagen *</label>
                                                    <input type="file" name="imagen" id="imagen" required/>
                                              </div>
                                              <div class="form-group">
                                            <button class="btn btn-primary" type="submit" name="submit"  onClick="listainscpago(<?= $user['campamento_id'] ?>)">Volver</button>
                                            <button type="sumit" class="btn btn-primary">Confirmar pago</button>
                                            </div>
                         </form>                        

                            </div>
                        </div>
                    </div>
                
                <?php
}
?>