<?php
require_once '../m/db_functions.php';
$id=$_POST['id'];
 $demo = new DB_Functions();
  $algs = $demo->listRol();
  $users = $demo->listUsuariosid($id);
?>          

          <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           PERMISO USUARIO
                        </div>
                        <div class="panel-body">
                       <form name="nuevo_permiso" method="POST" action="" onSubmit="insertpermisousuario(); return false">
                          <?php  

                               foreach ($users as $key => $uper) {?>
                                <div class="form-group">
                                  <label for="name">Usuario:</label>
                                  <input type="hidden" id="id" name="id" value="<?= $uper['usuario_id'] ?>" />
                                  <input type="text" name="name" id="name" class="form-control" placeholder="Name" value="<?= $uper['nombre'] ?>" disabled/>
                                </div>
                                <div class="form-group">
                                  <label for="text">Nombre completo:</label>
                                  <input type="text" name="nome" id="name" class="form-control" placeholder="nombre completo" value="<?= $uper['nombre_u'] ?> <?= $uper['apellido'] ?>" disabled/>
                                </div>
                                <div class="form-group">
                                   <label>Permiso</label>
                                    <select class="form-control" name="perm" required>
                                     <option value="">Elija una opcion</option>
                                          <?php 
                                               foreach ($algs as $key => $alg) {?>
                                                   <option value="<?= $alg['id'] ?>"> <?= $alg['nombre'] ?></option>
                                          <?php }?>
                                     </select>
                                </div>
                                <?php } ?>
                                <button class="btn btn-success" type="submit" id="enviar" name="enviar" value='insertar'>Enviar</button>
                           </form>
                            </div>
                            </div>
                    </div>
                   
                </div>