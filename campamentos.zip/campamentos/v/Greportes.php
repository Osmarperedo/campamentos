<?php
require_once '../m/db_functions.php';
    session_start();
    if(isset ($_SESSION['id'])) {
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Bootstrap Admin Template : Binary Admin</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   <!-- TABLE STYLES-->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="inicio.php">Inicio</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">  <a href="../index.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
					</li>
				
					
                              <li>
                        <a  href="#"> <strong>  
                        <?php 
                        echo $_SESSION['name'] ; 
                        echo " " ;  
                        echo $_SESSION['apellido']; 
                        ?> </strong></a>
                    </li>
                    <?php
                    $demo = new DB_Functions();
                    $rols = $demo->listpermisos($_SESSION['id']);

                    foreach ($rols as $key => $perm) {
                    if ($perm['recurso_id']===1){
                    ?>
                    <li>
                        <a class="active-menu"  href="Grol.php"><i class="fa fa-dashboard "></i> Gestion Roles</a>
                    </li>
                    <?php } if($perm['recurso_id']===2) {?>
                     <li>
                        <a  href="Gusuario.php"><i class="fa fa-desktop "></i> Gestión Usuarios</a>
                    </li>
                    <?php } if($perm['recurso_id']===3) {?>
                    <li>
                        <a  href="Gcampamento.php"><i class="fa fa-qrcode "></i> Gestion Campamentos</a>
                    </li>
                    <?php } if($perm['recurso_id']===4) {?>
                    <li  >
                        <a   href="Gregistros.php"><i class="fa fa-bar-chart-o "></i> Gestión Registros</a>
                    </li>   
                    <?php } if($perm['recurso_id']===5) {?>
                    <li  >
                        <a  href="Gpagos.php"><i class="fa fa-table "></i> Gestion Pagos</a>
                    </li>
                    <?php } if($perm['recurso_id']===6) {?>
                    <li  >
                        <a  href="Greportes.php"><i class="fa fa-edit "></i> Reportes </a>                  
                    </li>
                     <?php 
                     }   }
                     ?>                               
                </ul>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
            <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                               Buscar 
                            </div>
                            <div class="panel-body">
                             
                            <form class="form-inline" method="post" action="GReporte.php">
                              <div class="form-group">
                              <div class="checkbox">
                                <label>
                                  <input type="checkbox" value="enviados" name="enviados">  Enviados
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input type="checkbox" value="recibidos" name="recibidos"> Recibidos
                                </label>
                              </div>
                                <label class="sr-only" for="">Celular</label>
                                <input type="tel" class="form-control" id="cel" name="cel" placeholder="Celular" maxlength="8" onkeypress="return isNumberKey(event)">
                              </div>
                              <div class="form-group">
                                <label class="sr-only" for="">Fecha Inicial</label>
                                <input class="form-control" type="date" id="fi" name="fi">
                              </div>
                              <div class="form-group">
                                <label class="sr-only" for="">Fecha final</label>
                                <input class="form-control" type="date" id="ff" name="ff">
                              </div>
                              <button type="submit" class="btn btn-default"><i class="glyphicon glyphicon-search "></i> Buscar</button>
                            </form>
                            </div>
                         </div>
                    </div>
                </div>
                <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Advanced Tables
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>campamento</th>
                                            <th>Tipo</th>
                                            <th>Nombre completo</th>
                                            <th>Iglesia</th>
                                            <th>Inscripcion</th>
                                            <th>Pago</th>
                                            <th>Monto</th>
                                            <th>%</th>
                                            <th>P %</th>
                                            <th>Max P.</th>
                                            <th>Estado</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                     <?php
                                         $env="";
                                         $rec="";
                                        $cel="";
                                        $fi="";
                                        $ff="";
                                         if($_SERVER['REQUEST_METHOD']=='POST'){
                                            if(isset($_POST['enviados'])){
                                                $env= $_POST['enviados'];
                                            }
                                            if(isset($_POST['recibidos'])){
                                                $rec = $_POST['recibidos'];

                                            }
                                            if(isset($_POST['cel'])){
                                                $cel = $_POST['cel'];

                                            }
                                            if(isset($_POST['fi'])){
                                                $fi = $_POST['fi'];

                                            }
                                            if(isset($_POST['ff'])){
                                                $ff = $_POST['ff'];
                                            }
                                        }

                                        $demo = new DB_Functions();
                                        $users = $demo->reportegeneral();
                                        $i=1;
                                        foreach ($users as $key => $user) {
                                        ?>  
                                        <tr class="odd gradeX">
                                            <td><?= $i;?></td>
                                            <td><?= $user['nombrec'] ?></td>
                                            <td><?= $user['tipo_campamento'] ?></td>
                                            <td><?= $user['nombre'] ." ". $user['apellido'] ?></td>
                                            <td><?= $user['iglesia'] ?></td>
                                            <td><?= $user['fecha_inscripcion'] ?></td>
                                            <td><?= $user['fecha_pago'] ?></td>
                                            <td class="center"><?= $user['monto'] ?></td>
                                            <td class="center"><?= $user['descuento'] ?> %</td>
                                            <td class="center"><?= $user['cantidad'] ?></td>
                                            <td class="center"><?= $user['cupo_max'] ?></td>
                                            <td class="center"><?= $user['estado'] ?></td>
                                        </tr>
                                        <?php
                                                $i++;
                                                }
                                            ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   <script type="text/javascript" src="assets/js/ajax.js"></script>
    <script type="text/javascript" src="assets/js/validator.js"></script>
</body>
</html>
<?php
}else{
//header("Location: ../index.php"); 
header("Location: ../vista/error403.html"); } ?>
