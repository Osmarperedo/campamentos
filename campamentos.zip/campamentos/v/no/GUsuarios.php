<!--?php
require_once '../modelo/smsencrip.php';
ob_start();
    session_start();
    if(isset ($_SESSION['id'])) {
?-->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>SmSegurity</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />

       <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a  class="navbar-brand" href="inicio.php"><i class="glyphicon glyphicon-home"></i> Inicio 

                </a>
            </div>

            <div class="notifications-wrapper">
<ul class="nav">
               
              
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user-plus"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#" onClick="VerPerfilUsuario(<?= $_SESSION['id']?>); return false;"><i class="fa fa-user-plus"></i> Mi Perfil</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="../index.php"><i class="fa fa-sign-out"></i> Salir</a>
                        </li>
                    </ul>
                </li>
            </ul>
            </div>
        </nav>
         <!-- /. NAV TOP  -->
        <nav  class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="assets/img/user.jpg" class="img-circle" />

                           
                        </div>

                    </li>
                     <li>
                        <a  href="#"> <strong>  
                        <?php 
                        echo $_SESSION['name'] ; 
                        echo " " ;  
                        echo $_SESSION['apellido']; 
                        ?> </strong></a>
                    </li>
   <?php
                    $demo = new Smsencrip();
                    $rols = $demo->listpermisos(1);//($_SESSION['id']);
                    foreach ($rols as $key => $perm) {
                    if ($perm['recurso_id']===1){
                    ?>

                    <li>
                        <a   href="GRoles.php"><i class="glyphicon glyphicon-th-list "></i>Gestión Roles</a>
                    </li>
                    <?php } if($perm['recurso_id']===2) {?>
                    <li>
                        <a class="active-menu" href="GUsuarios.php"><i class="glyphicon glyphicon-user"></i>Gestión Usuarios</a>
                    </li>
                    <?php } if($perm['recurso_id']===3) {?>
                    <li>
                        <a href="GContactos.php"><i class="glyphicon glyphicon-phone"></i>Gestión Contactos</a>
                    </li>
                    <?php } if($perm['recurso_id']===4) {?>
                    <li>
                        <a  href="Ggrupos.php"><i class="glyphicon glyphicon-th"></i>Gestión Grupos </a>
                    </li>
                    <?php } if($perm['recurso_id']===5) {?>                    
                    <li>
                        <a href="GAlgoritmos.php"><i class="glyphicon glyphicon-qrcode"></i>Algoritmos</a>
                        
                    </li>
                    <?php } if($perm['recurso_id']===6) {?>
                     <li>
                        <a href="GReporte.php"><i class="glyphicon glyphicon-stats"></i>Reportes</a>
                    </li>
                    <?php } if($perm['recurso_id']===7) {?>
                    <li>
                        <a href="MensajesChat.php"><i class="fa fa-dashcube "></i>Envio mensajes</a>
                    </li>
                <?php 
                     }   }
                     ?>
                   
                </ul>
            </div>

        </nav>
        <!-- /. SIDEBAR MENU (navbar-side) -->
        <div id="page-wrapper" class="page-wrapper-cls">
            <div id="page-inner">
                <div class="row" id="alerta">                    
                    <div class="col-md-12">
                        <h1 class="page-head-line">Catalogo de Usuarios</h1>
                    </div>
                </div>
                <div class="" id="Form">
                      <!--    Striped Rows Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                    <?php
                        $pers = $demo->listperfrecurso(2,$_SESSION['id']);
                        foreach ($pers as $key => $per) {
                             if (!empty($per['agregar'])){
                    ?>

                             <button class="btn btn-success" type="submit" name="submit" onClick="nuevousuario()">Nuevo</button>
                    <?php } ?>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Usuario</th>
                                            <th>Nombre</th>
                                            <th>Apellidos</th>
                                            <th>Tipo</th>
                                            <th>Fecha Registro</th>
                                            <th>Estado</th>
                                            <th>Acción</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                            <?php
                                            
                                                $users = $demo->listUsuarios();
                                                $i=1;
                                                foreach ($users as $key => $user) {
                                            ?>
                                            <tr>
                                            <td><?= $i;?></td>
                                            <td><?= $user['nombre_u'] ?></td>
                                            <td><?= $user['nombre_p'] ?></td>
                                            <td><?= $user['apellido_p'] ?></td>
                                            <td><?= $user['nombre'] ?></td>
                                            <td><?= $user['created_at'] ?></td>
                                            <td><?= $user['deleted'] ?></td>
                                            <td> 
                                    <?php if(!empty($per['persmisousu'])) { ?>
                                                <button class="btn btn-info" type="submit" name="submit" onClick="verpermisousuario(<?= $user['usuario_id'] ?>)"><i class="fa fa-edit "></i> Permisos</button>
                                    <?php } if(!empty($per['contrasena'])) {?>
                                                <button type="button" class="btn btn-warning" onClick="resetpassusuario(<?= $user['usuario_id'] ?>,'<?= $user['nombre_u'] ?>')"><i class="fa fa-edit"></i>Contraseña</button>
                                    <?php } if(!empty($per['editar'])) {?>
                                                <button class="btn btn-primary" type="submit" name="submit" onClick="editarusuario(<?= $user['usuario_id'] ?>)"><i class="fa fa-edit "></i> Edit </button>
                                    <?php } if(!empty($per['eliminar'])) {?>
                                               <button type="button"class="btn btn-danger" onClick="eliminarusuario(<?= $user['usuario_id'] ?>)"><i class="fa fa-pencil" ></i> Delete</button>
                                    <?php }?>
                                            </td>
                                        </tr>
                                            <?php
                                                $i++;
                                                }
                                              }
                                            ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--  End  Striped Rows Table  -->
                        
                </div>
                
                </div>
            </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <footer >
        &copy; 2015 YourCompany | By : <a href="#" target="_blank">DesignBootstrap</a>
    </footer>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    <!--script type="text/javascript" src="assets/js/jquery.js"></script-->
    <!--language="JavaScript" type="text/javascript"-->
    <script type="text/javascript" src="assets/js/ajax.js"></script>
    <script type="text/javascript" src="assets/js/validator.js"></script>



</body>
</html>
<!--?php
}else{header("Location: ../vista/error403.html"); } ?-->

