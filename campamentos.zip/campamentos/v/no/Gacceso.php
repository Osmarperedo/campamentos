<?php
require_once '../m/db_functions.php';
session_start();
    if(isset ($_SESSION['id'])) {
?>
<div class="panel panel-default">
                                                <div class="panel-heading">
                                                 <?php
                                                    $demo = new DB_Functions();
                                                        $pers = $demo->listperfrecurso(7,$_SESSION['id']);
                                                        foreach ($pers as $key => $per) {
                                                             if (!empty($per['agregar'])){
                                                    ?>
                                                     <button class="btn btn-success" type="submit" name="submit" onClick="nuevoacceso()">Nuevo</button>
                                            <?php } ?>
                                                </div>
                                                <div class="panel-body">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <thead>
                                                                <tr>
                                                                    <th>#</th>
                                                                    <th>Perfil</th>
                                                                    <th>Fecha registro</th>
                                                                    <th>Acción</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                    <?php
                                                                        
                                                                        $users = $demo->listAcceos();
                                                                        $i=1;
                                                                        foreach ($users as $key => $user) {

                                                                    ?>
                                                                    <tr>
                                                                        <td><?= $i;?></td>
                                                                        <td><?= $user['nombre'] ?></td>
                                                                        <td><?= $user['fecha_registro'] ?></td>
                                                                        <td> 
                                                                    <?php  if(!empty($per['editar'])) {?>
                                                                        <button class="btn btn-primary" type="submit" name="submit" onClick="editaracceso(<?= $user['id'] ?>)"><i class="fa fa-edit "></i> Editar</button>

                                                                    <?php }?>
                                                                        </td>
                                                                        </tr>
                                                                    <?php
                                                                        $i++;
                                                                        }  } 
                                                                    ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
<?php
}else{
//header("Location: ../index.php"); 
header("Location: ../vista/error403.html"); } ?>
