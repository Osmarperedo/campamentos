                <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           NUEVO ACCESO
                        </div>
                        <div class="panel-body">
                          <form name="nuevoacc" method="POST" action="" onSubmit="insertacceso(); return false">
                              <div class="form-group">
                                <label for="nombre">Nombre </label>
                                <input style="text-transform:capitalize;" type="text" class="form-control" id="nombre" name="nombre" placeholder="Enter rol"  onkeypress="return soloLetras(event)"  required/>
                              </div>
                              <button type="submit" class="btn btn-default">Guardar</button>
                          </form>
                            </div>
                        </div>
                    </div>
                </div>