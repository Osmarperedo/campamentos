<?php
require_once '../m/db_functions.php';

$id=$_POST['id'];
    session_start();
    if(isset ($_SESSION['id'])) {
?>
<div class="col-md-12">
                        <div class="row" id="alerta">                    
                            <div class="col-md-12">
                                <h1 class="page-head-line">Lista Inscritos </h1>
                            </div>
                         </div>
                            <div class="" id="Form">
                                  <!--    Striped Rows Table  -->
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                    

                                        <?php
                                            $demo = new DB_Functions();
                                            $pers = $demo->listperfrecurso(4,$_SESSION['id']);//$_SESSION['id']);
                                            foreach ($pers as $key => $per) {
                                                 
                                        ?>
                                                 
                                    </div>
                                    <div class="panel-body">
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Nombre</th>
                                                        <th>Iglesisa</th>                        
                                                        <th>Fecha Inscripción</th>
                                                        <th>Fecha Pago</th>
                                                        <th>Monto</th>
                                                        <th>Factura</th>
                                                        <th>Estado</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                        <?php
                                                        //if ($_SESSION['perfil']===2){
                                                                //$users = $demo->listaRegistrosparti($_SESSION['id']);
                                                            //}else{
                                                                //$users = $demo->listaRegistros();
                                                                $users = $demo->listaiscritospago($id);
                                                            //}

                                                            //$users = $demo->listaiscritospago($id);
                                                            $i=1;
                                                            foreach ($users as $key => $user) {
                                                        ?>
                                                        <tr>
                                                        <td><?= $i;?></td>
                                                        <td><?= $user['nombre'] ." ". $user['apellido'] ?></td>
                                                        <td><?= $user['iglesia'] ?></td>               
                                                        <td><?= $user['fecha_inscripcion'] ?></td>
                                                        <td><?= $user['fecha_pago'] ?></td>
                                                        <td><?= $user['monto'] ?> Bs.</td>
                                                        <td><div class="thumbnail">
                                          
                                                            <img src="assets/img/batman.jpg" alt="User" width="110" height="68"><?= $user['imagen'] ?></div></td>
                                                                             
                                                        
                                                          <?php if(!empty($user['imagen'])) {?>
                                                          <td>Realizado</td>
                                                           
                                                           <?php }else{ ?>
                                                           <td> <button class="btn btn-primary" type="submit" name="submit" onClick="realizapago(<?= $user['idpago'] ?>)"><i class="fa fa-edit "></i>Pagar</button> </td>
                                                                  <?php }?>                             
                                                            </tr>
                                                                <?php
                                                                    $i++;
                                                                  }
                                                              }
                                                                ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- /. ROW  -->
                            </div>

                    </div>
                    <?php
}else{
//header("Location: ../index.php"); 
header("Location: ../vista/error403.html"); } ?>